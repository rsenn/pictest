/*********************************************************************
 *
 *                Microchip Full Speed USB Demo Tool Version 1.0
 *
 *********************************************************************
 * FileName:        codefrmPICDEMUSBFSDemoTool.h
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        Borland C++ Builder 6.0
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ravi Kumar M        11/04/04     Original.
 ********************************************************************
 *
 * VSK					09/2008		removed bootload tab
 *                                  and non standard components
 ********************************************************************/


#ifndef codefrmPICDEMUSBFSDemoToolH
#define codefrmPICDEMUSBFSDemoToolH

/* I N C L U D E S **********************************************************/
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <TabNotBk.hpp>
#include <Menus.hpp>
//#include "PERFGRAP.h"
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include "codeDeviceManager.h"

/* For ChangeAbortStatus function */
#define SAVE_CONTEXT    1
#define RESTORE_CONTEXT 0


/** D E C L A R A T I O N S **************************************************/
//---------------------------------------------------------------------------
/******************************************************************************
 * Class:    TWMDeviceChange
 *
 * Overview: Used by OnDeviceChange message handler
 *
 *
 * Note: None
 *
 *****************************************************************************/

struct TWMDeviceChange
{
    UINT Msg;
    UINT wParam;
    DWORD lParam;
    long Result;};

/******************************************************************************
 * Class:    TfrmFullSpeedUSBDemoTool
 *
 * Overview: Implement the main form behaviour of the application.
 *           It is responsible for communication among various objects
 *           in this application.
 *
 * Note: None
 *
 *****************************************************************************/

class TfrmFullSpeedUSBDemoTool : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *StatusBar;
		TButton *cmdClearScreen;
		TTimer *demoModeTimer;
		TPanel *Panel2;
			TRichEdit *txtMessage;
	TComboBox *cmbDEMOCommunicationChannel;
	TLabel *Label2;
	TButton *cmdConnect;
	TGroupBox *GroupBox4;
	TCheckBox *cbLED3;
	TCheckBox *cbLED4;
	TGroupBox *GroupBox3;
	TLabel *Label1;
	TLabel *Label6;
	TEdit *edtPOT;
	TRadioGroup *rgTimer;
	TGroupBox *GroupBox7;
	TLabel *Label3;
	TLabel *Label4;
	TButton *btnReadData;
	TEdit *edtNrOfData;
	TEdit *edtTimerIntv;
			void __fastcall Exit1Click(TObject *Sender);
			void __fastcall cmdConnectClick(TObject *Sender);
			void __fastcall cmbDEMOCommunicationChannelSelect(TObject *Sender);
			void __fastcall cmdClearScreenClick(TObject *Sender);
		void __fastcall FormCreate(TObject *Sender);
		void __fastcall demoModeTimerTimer(TObject *Sender);
		void __fastcall cmdIdentifyBoardsClick(TObject *Sender);
		void __fastcall cmdAbortOperationClick(TObject *Sender);
		void __fastcall cmbDEMOCommunicationChannelDropDown(TObject *Sender);
		void __fastcall FormResize(TObject *Sender);
	void __fastcall btnReadDataClick(TObject *Sender);
	void __fastcall rgTimerClick(TObject *Sender);
	void __fastcall edtTimerIntvChange(TObject *Sender);

private:	// User declarations
			bool Busy;
			DeviceManager  deviceManager;

			void DisableDemoInterface();
			void EnableDemoInterface();

			void ResetDemoMode();
			void CheckConfiguration(AnsiString& Config);
			void ShowWarning(AnsiString WarningText);
			void ShowMessage(AnsiString WarningText);
			void ShowStatusMessage(AnsiString Message);
			void ProcessPOT(UINT POT);

			void __fastcall OnDeviceChange(TWMDeviceChange& Message);

public:		// User declarations
			__fastcall TfrmFullSpeedUSBDemoTool(TComponent* Owner);

BEGIN_MESSAGE_MAP
		MESSAGE_HANDLER(WM_DEVICECHANGE, TWMDeviceChange, OnDeviceChange)
END_MESSAGE_MAP(TForm)
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmFullSpeedUSBDemoTool *frmFullSpeedUSBDemoTool;
//---------------------------------------------------------------------------
#endif
