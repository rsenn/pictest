﻿namespace USB_IO_Board_Controller
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboCOMPorts = new System.Windows.Forms.ComboBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StatusBar = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.RichTextBox();
            this.cboCommandInput = new System.Windows.Forms.ComboBox();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboCOMPorts
            // 
            this.cboCOMPorts.FormattingEnabled = true;
            this.cboCOMPorts.Location = new System.Drawing.Point(3, 4);
            this.cboCOMPorts.Name = "cboCOMPorts";
            this.cboCOMPorts.Size = new System.Drawing.Size(70, 21);
            this.cboCOMPorts.TabIndex = 0;
            this.cboCOMPorts.SelectedIndexChanged += new System.EventHandler(this.cboCOMPorts_SelectedIndexChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 121);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(404, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StatusBar
            // 
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Size = new System.Drawing.Size(0, 17);
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(344, 3);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(55, 23);
            this.btnSend.TabIndex = 3;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.Enabled = false;
            this.txtOutput.Location = new System.Drawing.Point(79, 30);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(259, 86);
            this.txtOutput.TabIndex = 4;
            this.txtOutput.Text = "";
            // 
            // cboCommandInput
            // 
            this.cboCommandInput.FormattingEnabled = true;
            this.cboCommandInput.Items.AddRange(new object[] {
            "Configure all ports as output:",
            "C,0,0,0,0",
            "",
            "Configure A0 as analogue input:",
            "C,1,0,0,1",
            "",
            "Sample Analog Input:",
            "A",
            "",
            "Output:",
            "O,0,255,0",
            "O,0,0,0",
            "",
            "Set Pin Output State (High/Low):",
            "PO,B,7,1",
            "PO,B,7,0",
            "",
            "Set Pin Direction (Input or Output):",
            "PD,A,0,1",
            "PD,A,0,0",
            "",
            "Read Pin Input State (High/Low)",
            "PI,B,7"});
            this.cboCommandInput.Location = new System.Drawing.Point(79, 4);
            this.cboCommandInput.Name = "cboCommandInput";
            this.cboCommandInput.Size = new System.Drawing.Size(259, 21);
            this.cboCommandInput.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 143);
            this.Controls.Add(this.cboCommandInput);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.cboCOMPorts);
            this.Name = "Form1";
            this.Text = "USB IO Board Controller - www.electronics-diy.com";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboCOMPorts;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StatusBar;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.RichTextBox txtOutput;
        private System.Windows.Forms.ComboBox cboCommandInput;
    }
}

