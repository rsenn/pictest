﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboCOMPorts = New System.Windows.Forms.ComboBox
        Me.btnSendCommand = New System.Windows.Forms.Button
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusBar = New System.Windows.Forms.ToolStripStatusLabel
        Me.cboCommandInput = New System.Windows.Forms.ComboBox
        Me.txtOutput = New System.Windows.Forms.TextBox
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboCOMPorts
        '
        Me.cboCOMPorts.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCOMPorts.FormattingEnabled = True
        Me.cboCOMPorts.Location = New System.Drawing.Point(2, 2)
        Me.cboCOMPorts.Name = "cboCOMPorts"
        Me.cboCOMPorts.Size = New System.Drawing.Size(70, 24)
        Me.cboCOMPorts.TabIndex = 0
        '
        'btnSendCommand
        '
        Me.btnSendCommand.Location = New System.Drawing.Point(343, 3)
        Me.btnSendCommand.Name = "btnSendCommand"
        Me.btnSendCommand.Size = New System.Drawing.Size(58, 23)
        Me.btnSendCommand.TabIndex = 2
        Me.btnSendCommand.Text = "Send"
        Me.btnSendCommand.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusBar})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 121)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(404, 22)
        Me.StatusStrip1.TabIndex = 4
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusBar
        '
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Size = New System.Drawing.Size(0, 17)
        '
        'cboCommandInput
        '
        Me.cboCommandInput.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCommandInput.FormattingEnabled = True
        Me.cboCommandInput.Items.AddRange(New Object() {"Configure all ports as output:", "C,0,0,0,0", "", "Configure A0 as analogue input:", "C,1,0,0,1", "", "Sample Analog Input:", "A", "", "Output:", "O,0,255,0", "O,0,0,0", "", "Set Pin Output State (High/Low):", "PO,B,7,1", "PO,B,7,0", "", "Set Pin Direction (Input or Output):", "PD,A,0,1", "PD,A,0,0", "", "Read Pin Input State (High/Low)", "PI,B,7"})
        Me.cboCommandInput.Location = New System.Drawing.Point(78, 3)
        Me.cboCommandInput.Name = "cboCommandInput"
        Me.cboCommandInput.Size = New System.Drawing.Size(259, 22)
        Me.cboCommandInput.TabIndex = 5
        '
        'txtOutput
        '
        Me.txtOutput.Enabled = False
        Me.txtOutput.Location = New System.Drawing.Point(78, 31)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtOutput.Size = New System.Drawing.Size(259, 86)
        Me.txtOutput.TabIndex = 8
        '
        'Form1
        '
        Me.AcceptButton = Me.btnSendCommand
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 143)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.cboCommandInput)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btnSendCommand)
        Me.Controls.Add(Me.cboCOMPorts)
        Me.Name = "Form1"
        Me.Text = "USB IO Board Controller - www.electronics-diy.com"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboCOMPorts As System.Windows.Forms.ComboBox
    Friend WithEvents btnSendCommand As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusBar As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents cboCommandInput As System.Windows.Forms.ComboBox
    Friend WithEvents txtOutput As System.Windows.Forms.TextBox

End Class
