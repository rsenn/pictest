das ist eine Version fuer die Homepage
mit Abfrage des Jumpers


    0x04D8,                 // Vendor ID
    0xFF0B,                 // Product ID: Sprut


// LED h�ngt an RB7 (LED1 gr�n)


/* Bootloader Version */
#define MINOR_VERSION   0x02    //Bootloader Version 2
#define MAJOR_VERSION   0x01	//Bootloader 
