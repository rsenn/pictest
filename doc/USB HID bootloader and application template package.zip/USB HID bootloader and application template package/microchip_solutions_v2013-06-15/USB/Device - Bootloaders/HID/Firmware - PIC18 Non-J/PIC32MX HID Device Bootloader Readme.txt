The PIC32MX HID Device Bootloader is a part of Microchip Application Note AN1388. The
application note can be downloaded from the following link:
http://www.microchip.com/stellent/idcplg?IdcService=SS_GET_PAGE&nodeId=1824&appnote=en554836