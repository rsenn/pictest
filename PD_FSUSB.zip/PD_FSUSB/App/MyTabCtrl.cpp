// MyTabCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "MyTabCtrl.h"

#define TAB_HT		24
#define TABS_MARGIN	3
#define IDC_TAB_AUTOCONNECT	10001
#define IDC_TAB_AUTOSELECT	10002


// CMyTabCtrl

IMPLEMENT_DYNAMIC(CMyTabCtrl, CTabCtrl)

CMyTabCtrl::CMyTabCtrl() :
	m_pDlgBoot(NULL),
	m_pDlgDemo(NULL)
{

}

CMyTabCtrl::~CMyTabCtrl()
{
	delete m_pDlgBoot;
	delete m_pDlgDemo;
}

void CMyTabCtrl::OnDeviceChanged()
{
	theApp.m_DeviceMgr.CloseDevice();
	theApp.m_DeviceMgr.ClearDeviceList();
	ChooseActiveTab();
}

void CMyTabCtrl::ChooseActiveTab(bool fForce)
{
	int nBoot = theApp.m_DeviceMgr.GetDeviceCount(PDMODE_BOOT);
	int nDemo = theApp.m_DeviceMgr.GetDeviceCount(PDMODE_DEMO);
	int nSel = -1;
	CString sStatus;
	if(nBoot || nDemo)
	{
		if(nDemo > nBoot)
		{
			nSel = PDMODE_DEMO;
			sStatus = "Demo device attached";
		}
		else
		{
			nSel = PDMODE_BOOT;
			sStatus = "Boot device attached";
		}
	}
	else
		m_staticMsg.GetWindowText(sStatus);

	theApp.SetStatusMessage(sStatus);

	if((-1==nSel) && (nBoot || nDemo) && !m_chkAutoSelect.GetCheck())
		nSel = PDMODE_BOOT;	// Show something 
	//this->SetCurSel(nSel);
	ShowTab(nSel, fForce);
//	OnTcnSelchange(NULL, NULL);

}

#define ZZZ(zzz)	case DBT_##zzz: /*TRACE("%s\n", #zzz);*/ break;
void CMyTabCtrl::OnDeviceChange(UINT nEventType, DEV_BROADCAST_HDR* pdbh)
{
//#include "C:\\MCHPFSUSB\\Pc\\MCHPUSB Driver\\Release\\Ioctls.h"

	switch(nEventType)
	{
		ZZZ(CONFIGCHANGECANCELED);
		ZZZ(CONFIGCHANGED);
		ZZZ(CUSTOMEVENT);
		ZZZ(DEVICEARRIVAL);
		ZZZ(DEVICEQUERYREMOVE);
		ZZZ(DEVICEQUERYREMOVEFAILED);
		ZZZ(DEVICEREMOVECOMPLETE);
		ZZZ(DEVICEREMOVEPENDING);
		ZZZ(DEVICETYPESPECIFIC);
		ZZZ(DEVNODES_CHANGED);
		ZZZ(QUERYCHANGECONFIG);
		ZZZ(USERDEFINED);
	} 

/*
	if(DBT_DEVICEREMOVECOMPLETE == nEventType)
	{
		if(pdbh && (DBT_DEVTYP_DEVICEINTERFACE == pdbh->dbch_devicetype) )
		{
			DEV_BROADCAST_DEVICEINTERFACE* pdb = (DEV_BROADCAST_DEVICEINTERFACE*)pdbh;
			if(IsMyVidPid(pdb->dbcc_name))
			{
			}
		}
	}
*/
	if( (DBT_DEVICEARRIVAL == nEventType) || (DBT_DEVICEREMOVECOMPLETE == nEventType) )
		ChooseActiveTab();
}

BEGIN_MESSAGE_MAP(CMyTabCtrl, CTabCtrl)
	ON_NOTIFY_REFLECT(TCN_SELCHANGE, &CMyTabCtrl::OnTcnSelchange)
	ON_BN_CLICKED(IDC_TAB_AUTOCONNECT, &CMyTabCtrl::OnBnClickedAutoConnect)
	ON_BN_CLICKED(IDC_TAB_AUTOSELECT, &CMyTabCtrl::OnBnClickedAutoSelect)
END_MESSAGE_MAP()

// CMyTabCtrl message handlers
static void CreateCheckbox(CWnd* pParent, UINT uIdc, CRect& rc, CButton& chk, LPCSTR psCaption, CFont* pFont)
{
	chk.Create(psCaption, WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX, rc, pParent, uIdc);
	int nInit = theApp.GetProfileInt("settings", psCaption, 1);
	chk.SetCheck(nInit);
	chk.SetFont(pFont);
}

void CMyTabCtrl::PreSubclassWindow()
{
	CFont* pFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));

	CRect rc;
	GetClientRect(&rc);
	rc.left = ((rc.Width()-150)/2);
	rc.right = rc.left + 150;
	rc.top = ((rc.Height()-20)/2);
	rc.bottom = rc.top + 20;
	m_staticMsg.Create("No Devices Attached", WS_CHILD|WS_VISIBLE|SS_CENTER, rc, this);
	m_staticMsg.SetFont(pFont);

	GetClientRect(&rc);
	rc.left = rc.right-90;
	rc.bottom = rc.top +20;
	CreateCheckbox(this, IDC_TAB_AUTOCONNECT, rc, m_chkAutoConnect, "AutoConnect", pFont);

	rc.OffsetRect(-90, 0);
	CreateCheckbox(this, IDC_TAB_AUTOSELECT, rc, m_chkAutoSelect, "AutoSelect", pFont);

	// TODO: Add your specialized code here and/or call the base class
	this->InsertItem(PDMODE_BOOT, "Bootload Mode");
	this->InsertItem(PDMODE_DEMO, "Demo Mode");

//	CRect rc;
	GetClientRect(&rc);
	rc.DeflateRect(2*TABS_MARGIN,2*TABS_MARGIN);
	rc.bottom -= TAB_HT;

	m_pDlgBoot = new CTabBootload;
	m_pDlgBoot->CreateTab(this, TABS_MARGIN, TAB_HT, rc.Width(), rc.Height());

	m_pDlgDemo = new CTabDemo;
	m_pDlgDemo->CreateTab(this, TABS_MARGIN, TAB_HT, rc.Width(), rc.Height());

	OnBnClickedAutoConnect();
	ChooseActiveTab(true);

	CTabCtrl::PreSubclassWindow();
}

void CMyTabCtrl::OnTcnSelchange(NMHDR *pNMHDR, LRESULT *pResult)
{
	PDMODE nSel = (PDMODE)this->GetCurSel();
	ShowTab(nSel, true);
	*pResult = 0;
}

void CMyTabCtrl::ShowTab(int nTab, bool fForce)
{
	if(fForce || m_chkAutoSelect.GetCheck())
	{
		this->SetCurSel(nTab);

		// Deactivate both so that active dlg releases resources
		if(PDMODE_BOOT != nTab)
			m_pDlgBoot->Activate(false);
		if(PDMODE_DEMO != nTab)
			m_pDlgDemo->Activate(false);

		// Activate the new mode
		if(PDMODE_BOOT == nTab)
			m_pDlgBoot->Activate(true);
		if(PDMODE_DEMO == nTab)
			m_pDlgDemo->Activate(true);
	}
}

void CMyTabCtrl::OnBnClickedAutoConnect()
{
	bool fAuto = (BST_CHECKED==m_chkAutoConnect.GetCheck());
	m_pDlgBoot->SetAutoConnect(fAuto);
	m_pDlgDemo->SetAutoConnect(fAuto);
	theApp.WriteProfileInt("settings", "AutoConnect", fAuto);
}

void CMyTabCtrl::OnBnClickedAutoSelect()
{
	bool fAuto = (BST_CHECKED==m_chkAutoSelect.GetCheck());
	if(fAuto)
		ChooseActiveTab();
	theApp.WriteProfileInt("settings", "AutoSelect", fAuto);
}
