#pragma once

#include "defs.h"
#include "ByteBuf.h"


#define USB_PACKET_SIZE		64	// The USB transport uses 64 byte packets
#define USB_PACKET_HDR_SIZE	5	// <CMD_CODE><LEN><ADDR:3>
#define USB_PACKET_DATA_SIZE   (USB_PACKET_SIZE - USB_PACKET_HDR_SIZE)

// The 5-byte header sent by commands that read/write chip memory
typedef struct _USBPACKETHDR
{
	BYTE cmd;	// A FWCMD_xxxx value
	BYTE len;
	union
	{
		struct
		{
			BYTE low;                   // Little-endian order
			BYTE high;
			BYTE upper;
		};
	}addr;
} USBPACKETHDR;

// Struct that maps our use of the 64-byte packet sent/recieved to/from the board.
typedef union _USBPACKET
{
    BYTE raw[USB_PACKET_SIZE];  //For per-byte access
    struct
    {
		USBPACKETHDR hdr;
        BYTE data[USB_PACKET_DATA_SIZE];
	};
} USBPACKET;

// Ths struct holds all data pertaining to a "USB Transaction" - one 
//   cycle of sending a command plus optional related data data to the 
//   board then reading back whatever the board has for us for that 
//   specific command.
struct USBTXN
{
	struct
	{
		USBPACKET pkt;				// The data that's sent to the board
		BYTE count;					// # of bytes in buf to be sent
		UINT timeout;				// # of ms to wait for async i/o to complete
	} tx;
	struct
	{
		BYTE buf[USB_PACKET_SIZE];	// Bytes received from the board (not formatted like tx hdr)
		struct
		{
			BYTE expected;			// # of bytes we're expecting to rx
			BYTE actual;			// # of bytes we actually rx'ed
		} count;
		UINT timeout;				// # of ms to wait for async i/o to complete
	} rx;
	USBTXN()
	{
		_ctor();
	}
	USBTXN(FWCMD cmd, BYTE rxcount)
	{
		_ctor();
		this->AddTxByte(cmd);
		this->rx.count.expected = rxcount;
	}
	void _ctor()	// protected
	{
		memset(this, 0, sizeof(USBTXN));
		this->tx.timeout = 500;
		this->rx.timeout = 1000;
	}
	void PrepMemCmdPktHdr(FWCMD cmd, BYTE len, DWORD Addr)
	{
		this->tx.pkt.hdr.cmd = cmd;
		this->tx.pkt.hdr.len = len;	// Tell firmware how many data bytes (if any) follow this 5 byte header
		this->tx.pkt.hdr.addr.low = (BYTE) (Addr&0x000000FF);
		this->tx.pkt.hdr.addr.high = (BYTE)((Addr&0x0000FF00) >> 0x08);
		this->tx.pkt.hdr.addr.upper = (BYTE)((Addr&0x00FF0000) >> 0x10);
		this->tx.count = sizeof(this->tx.pkt.hdr);
		ASSERT(USB_PACKET_HDR_SIZE == this->tx.count);
		switch(cmd)
		{
			// These commands take a bit longer to complete
			case CMD_READ_FLASH:	this->rx.timeout = 3000;	break;
			case CMD_ERASE_FLASH:	this->rx.timeout = 5000;	break;
		}
	}
	void AddTxByte(BYTE b)
	{
		this->tx.pkt.raw[this->tx.count] = b;
		this->tx.count++;
	}
	bool ValidateRxData(BYTE nRx, BYTE nHdr)
	{
		if(nRx != this->rx.count.actual)
			return false;
		for(BYTE z=0; z<nHdr; z++)
		{
			if(this->tx.pkt.raw[z] != this->rx.buf[z])
				return false;
		}
		return true;
	}
};

// Helper class for CDemoBoard
// Encapsulates the USB connection
class USBPort
{
public:
	USBPort(int assignedIndex);
	~USBPort();
	bool Open(PDMODE mode);
	void Close();
	bool DoUsbTransaction(USBTXN& txn);
protected:
	static HANDLE m_hBulkOut,m_hBulkIn;
	int m_nAssignedIndex;
};

// Encapsulates the connection to a FS USB Board
class CDemoBoard
{
public:
	CDemoBoard(LPCSTR psDeviceName, PDMODE mode, int assignedIndex);
	virtual ~CDemoBoard();

	int m_nDemoDevID;	// Used in Demo Mode to identify the device
						// Device identification can be {00b,01b,02b,03b}
	CString m_sDeviceName;

	bool Open();
	void Close();
	bool DoUsbTransaction(USBTXN& txn)	{return m_usb.DoUsbTransaction(txn);}

	PDMODE GetMode()			{return m_mode;}
	inline bool IsDisabled()	{return m_fDisabled;}  

protected:
	static int m_nUsedDevIDs[4];
	PDMODE m_mode;
	USBPort m_usb;
	int m_nAssignedIndex;
	bool m_fDisabled;
};

/******************************************************************************
 * Class:    DeviceManager
 *
 * Overview: This class implements the functionality to manages all the connected
 *           boards. It also implements the functionality required to communicate
 *           with boards and the Bootload protocol.
 *
 * Note: None
 *
 *****************************************************************************/
class DeviceManager
{
public:
	DeviceManager();
	~DeviceManager();

	PDMODE m_ActiveMode; /* Boot, Demo */
	bool m_fAbortOperation;

	UINT GetDeviceCount(PDMODE mode);

	void ClearDeviceList();

	bool SelectDevice(LPCSTR psDeviceName);
	bool IsDeviceSelected()	{return NULL != m_pCurrentBoard;}
	bool OpenDevice();
	void CloseDevice();
	void Refresh();
	void FillDeviceCombo(CComboBox& combo);

	void SetActiveMode(PDMODE mode)
	{
		if(m_ActiveMode != mode)
		{
			CloseDevice();
			ClearDeviceList();
		}
		m_ActiveMode = mode;
	}

	// Commands To Be handled
	// All commands are available to both modes

	// Boot Mode
	CString ReadVersion();
	bool EraseMem(MEMGRP mg);
	CByteBuf* ReadFLASH(UINT Addr, UINT Len)		{return readmem(MG_PGM, Addr, Len);}
	bool WriteFLASH(DWORD dwAddr, CByteBuf& data)	{return writemem(MG_PGM, dwAddr, data);}
	bool WriteUID(CByteBuf& data)					{return writemem(MG_UID, 0, data);}
	CByteBuf* ReadEEDATA(UINT Addr, UINT Len)		{return readmem(MG_EE, Addr, Len);}
	bool WriteEEDATA(CByteBuf& data)				{return writemem(MG_EE, 0, data);}
	CByteBuf* ReadCONFIG(UINT Addr, UINT Len)		{return readmem(MG_CFG, Addr, Len);}
	bool WriteCONFIG(CByteBuf& data)				{return writemem(MG_CFG, 0, data);}
	bool ResetBoard();

	//Demo Mode
	bool UpdateLED(UINT led, int nOn);
	void SetTempRealMode();
	bool ReadTemperature(WORD& wTemperature);
	void SetTempLogging();
	bool ReadTempLogging(CByteBuf& bbData);
	bool ReadPot(WORD& wPotValue);

protected:
	CTypedPtrArray<CPtrArray, CDemoBoard*> m_paBoards;
	CDemoBoard *m_pCurrentBoard;
	bool m_fIsOpen;

	CByteBuf* readmem(MEMGRP mg, UINT Addr, UINT Len);
	bool writemem(MEMGRP mg, UINT uRelAddr, CByteBuf& data);

};
//---------------------------------------------------------------------------

