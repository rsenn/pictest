// Led.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "Led.h"


// CLed

IMPLEMENT_DYNAMIC(CLed, CStatic)

CLed::CLed() :
	m_fOn(FALSE)
{

}

CLed::~CLed()
{
}

BEGIN_MESSAGE_MAP(CLed, CStatic)
	ON_WM_PAINT()
	ON_CONTROL_REFLECT(STN_CLICKED, &CLed::OnStnClicked)
	ON_WM_ENABLE()
END_MESSAGE_MAP()

// CLed message handlers
void CLed::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CStatic::OnPaint() for painting messages

	COLORREF crBk = GetSysColor(COLOR_3DFACE);

	CRect rc;
	GetClientRect(&rc);
	dc.FillSolidRect(&rc, crBk);

	int z = min(rc.Width(), rc.Height());
	int w = rc.right;
	rc.right = rc.left+z;

	CPen pen(PS_SOLID, 1, RGB(0x00, 0x00, 0x00));
	CPen* pOldPen = dc.SelectObject(&pen);
	dc.Rectangle(&rc);
	dc.SelectObject(pOldPen);
	rc.DeflateRect(1,1);
	COLORREF crLed = GetSysColor(COLOR_3DSHADOW);
	if(IsWindowEnabled())
		crLed = RGB(0,(m_fOn?0xff:0x7f),0);
	dc.FillSolidRect(&rc, crLed);
	rc.InflateRect(1,1);

	dc.SetBkColor(crBk);
	CString sCaption;
	GetWindowText(sCaption);
	rc.left = rc.right+2;
	rc.right = w;

	CFont* pTextFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));
	CFont* pOldFont = dc.SelectObject(pTextFont);
	dc.DrawText(sCaption, rc, DT_LEFT);
	dc.SelectObject(pOldFont);
}

void CLed::OnStnClicked()
{
	m_fOn = !m_fOn;
	Invalidate();
}

void CLed::OnEnable(BOOL bEnable)
{
	CStatic::OnEnable(bEnable);
	if(!bEnable)
		m_fOn = FALSE;
	Invalidate();

	// TODO: Add your message handler code here
}
