#pragma once

#include "DisabledImage.h"
// CBmpCtrl

class CBmpCtrl : public CWnd
{
	DECLARE_DYNAMIC(CBmpCtrl)

public:
	CBmpCtrl(UINT uIdb);
	virtual ~CBmpCtrl();

	BOOL CreateFromAlias(CWnd* pParentDlg, UINT id);
	void ResizeToImg(CImage* pImg=NULL);

protected:
	DECLARE_MESSAGE_MAP()

	CImage m_img;
	CDisabledImage m_imgDisbl;
	static CString m_sClassname;

	virtual void PrePaintBg(CPaintDC& dc)		{}
	virtual CImage* GetBgImg();
	virtual void PostPaintBg(CPaintDC& dc)		{}

public:
	afx_msg void OnPaint();
	afx_msg void OnEnable(BOOL bEnable);
protected:
	virtual void PreSubclassWindow();
};


