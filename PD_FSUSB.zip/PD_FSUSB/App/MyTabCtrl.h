#pragma once

#include "TabBootload.h"
#include "TabDemo.h"
#include <Dbt.h>	//DEV_BROADCAST_HDR

// CMyTabCtrl

class CMyTabCtrl : public CTabCtrl
{
	DECLARE_DYNAMIC(CMyTabCtrl)

public:
	CMyTabCtrl();
	virtual ~CMyTabCtrl();

	void OnDeviceChanged();
	void OnDeviceChange(UINT nEventType, DEV_BROADCAST_HDR* pdbh);

protected:
	CTabBootload* m_pDlgBoot;
	CTabDemo* m_pDlgDemo;
	CStatic m_staticMsg;
	CButton m_chkAutoSelect;
	CButton m_chkAutoConnect;

	void ChooseActiveTab(bool fForce=false);
	void ShowTab(int nTab, bool fForce=false);

	DECLARE_MESSAGE_MAP()
public:
protected:
	virtual void PreSubclassWindow();
public:
	afx_msg void OnTcnSelchange(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedAutoConnect();
	afx_msg void OnBnClickedAutoSelect();
};
