#pragma once

#include "DisabledImage.h"

// CBmpButton

class CBmpButton : public CButton
{
	DECLARE_DYNAMIC(CBmpButton)

public:
	CBmpButton(UINT uIdb);
	virtual ~CBmpButton();

protected:
	CImage m_imgEnbl;
	CDisabledImage m_imgDisabled, m_imgDisblShadow;

	DECLARE_MESSAGE_MAP()
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT /*lpDrawItemStruct*/);
	afx_msg void OnEnable(BOOL bEnable);
protected:
	virtual void PreSubclassWindow();
};


