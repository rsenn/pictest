// TabDemo.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "TabDemo.h"


#define IDT_DEMOMODE	100
#define CONNECTBTN_TEXT_CONNECT		"&Connect"
#define CONNECTBTN_TEXT_DISCONNECT	"&Disconnect"


// CTabDemo dialog

IMPLEMENT_DYNAMIC(CTabDemo, CTabDlg)

CTabDemo::CTabDemo() :
	CTabDlg(CTabDemo::IDD),
	m_fRealtimeTemp(TRUE)
{
}

CTabDemo::~CTabDemo()
{
}

void CTabDemo::Activate(bool fActivate)
{
	ShowWindow(fActivate?SW_SHOW:SW_HIDE);
	if(fActivate)
	{
		theApp.m_DeviceMgr.SetActiveMode(PDMODE_DEMO);
		OnCbnDropdownDemoCombo();	// Refresh device list, re-populate combo
		if(m_fAutoConnect)
		{
			if(m_comboChannel.GetCount()>0)
				m_comboChannel.SetCurSel(0);
		}
		Connect(m_fAutoConnect);
		theApp.SetStatusReady();
	}
	else
	{
		EnableTimer(false);
		m_comboChannel.ResetContent();
		m_TempGraph.ClearData();
	}
}

void CTabDemo::SetAutoConnect(bool fAuto)
{
	CTabDlg::SetAutoConnect(fAuto);	// Call base 1st to update m_fAutoConnect
	if(fAuto)
		Activate(true);
//	OnCbnSelchangeDemoCombo();
}

void CTabDemo::SetTempMode(BOOL fRealtime)
{
	m_fRealtimeTemp = fRealtime;
	((CButton*)GetDlgItem(IDC_DEMO_TEMP_REAL))->SetCheck(m_fRealtimeTemp);
	((CButton*)GetDlgItem(IDC_DEMO_TEMP_LOG))->SetCheck(!m_fRealtimeTemp);
	GetDlgItem(IDC_DEMO_TEMP_LOG_ACQUIRE)->EnableWindow(!m_fRealtimeTemp);

	if(m_fRealtimeTemp)
        theApp.m_DeviceMgr.SetTempRealMode();
	else	
		theApp.m_DeviceMgr.SetTempLogging();
}

CString CTabDemo::ProcessTemperature(WORD wTemperature)
{
	char chSign;

    WORD wTemp = (wTemperature >> 3);

    if ( (wTemp & 0x1000) == 0x0)
    {
        wTemp &= 0x1FFF; //0b00011111
        chSign = '+';
    }
    else
    {
        wTemp |= 0xE000; //0b11100000
        chSign = '-';
        wTemp = (wTemp ^ 0xFFFF); // Negate
        wTemp++;
    }
    wTemp = (wTemp*10U) >> 4; 

	double dTemp = ((double)wTemp)/10.0;	// Temp in degrees celsius
	m_TempGraph.AddDatum(dTemp);
	char chUnit = 'C';

	if(((CButton*)GetDlgItem(IDC_DEMO_UNIT_F))->GetCheck())
	{
		chUnit = 'F';
		dTemp = ((dTemp*9)/5)+32;	// Convert C to F for display string
	}

    CString sTemp;
	sTemp.Format("%c%2.1f%c%c", chSign, dTemp, 176, chUnit);
    // Show in the Text Box
	SetDlgItemText(IDC_DEMO_TEMP_VAL, sTemp);
	return sTemp;
}

void CTabDemo::ProcessPOT(WORD wPot)
{
    int nOhms = (int)(((double)wPot/(double)1023.0)*(double)10000.0);
	SetDlgItemInt(IDC_DEMO_POT_RES, nOhms);
	m_PotValueDial.SetValue(nOhms);
}

void CTabDemo::Connect(bool fConnect)
{
	if (fConnect) 
	{
		int nSel = m_comboChannel.GetCurSel();
		m_btnConnect.EnableWindow(nSel >= 0);
		if(nSel >= 0)
		{
			CString sSel;
			m_comboChannel.GetLBText(nSel, sSel);
			if(theApp.m_DeviceMgr.SelectDevice(sSel))
			{
				theApp.SetStatusMessage("Connecting to board...");
				if (theApp.m_DeviceMgr.OpenDevice()) 
				{
					theApp.SetStatusMessage("USB Demo Firmware Version " + theApp.m_DeviceMgr.ReadVersion() );
					ShowConnect(false);
					m_comboChannel.EnableWindow(FALSE);
					EnableControls(true);
					SetTempMode(m_chkTempRealtime.GetCheck());
				}
			}
		}
	}
	else
	{
		EnableControls(false);
		theApp.m_DeviceMgr.CloseDevice();
		ShowConnect(true);
		if(m_comboChannel.GetCurSel() == -1)
			m_btnConnect.EnableWindow(FALSE);
		else
			m_btnConnect.EnableWindow(TRUE);
		m_comboChannel.EnableWindow(TRUE);
		theApp.SetStatusReady();
	}
}

void CTabDemo::EnableControls(bool fEnable)
{
	m_PotValueDial.EnableWindow(fEnable);
	m_TempGraph.EnableWindow(fEnable);
	m_editPotRes.EnableWindow(fEnable);
	m_chkTempRealtime.EnableWindow(fEnable);
	m_chkTempLog.EnableWindow(fEnable);
	m_led3.EnableWindow(fEnable);
	m_led4.EnableWindow(fEnable);

	if(fEnable)
	{
		if(m_chkTempRealtime.GetCheck())
		{
			m_btnAcquireTempData.EnableWindow(FALSE);
			m_editTempVal.EnableWindow(TRUE);
			EnableTimer(true);
		}
		if(m_chkTempLog.GetCheck())
		{
			m_btnAcquireTempData.EnableWindow(TRUE);
			m_editTempVal.EnableWindow(FALSE);
			EnableTimer(false);
		}
	}
	else
	{
		EnableTimer(false);
		m_btnAcquireTempData.EnableWindow(FALSE);
		m_editTempVal.EnableWindow(FALSE);

		m_editTempVal.SetWindowText("");
		m_editPotRes.SetWindowText("");
	}
}

void CTabDemo::EnableTimer(bool fEnable)
{
	KillTimer(IDT_DEMOMODE);
	if(fEnable)
		SetTimer(IDT_DEMOMODE, 250, NULL);
}

void CTabDemo::ShowCelsius(bool fCelsius)
{
	((CButton*)GetDlgItem(IDC_DEMO_UNIT_C))->SetCheck(fCelsius);
	((CButton*)GetDlgItem(IDC_DEMO_UNIT_F))->SetCheck(!fCelsius);
	m_TempGraph.ShowCelsius(fCelsius);
}

void CTabDemo::DoDataExchange(CDataExchange* pDX)
{
	CTabDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DEMO_POTVALUEDIAL, m_PotValueDial);
	DDX_Control(pDX, IDC_DEMO_LED4, m_led4);
	DDX_Control(pDX, IDC_DEMO_LED3, m_led3);
	DDX_Control(pDX, IDC_DEMO_TEMPGRAPH, m_TempGraph);
	DDX_Control(pDX, IDC_DEMO_TEMP_VAL, m_editTempVal);
	DDX_Control(pDX, IDC_DEMO_POT_RES, m_editPotRes);
	DDX_Control(pDX, IDC_DEMO_COMBO, m_comboChannel);
	DDX_Control(pDX, IDC_DEMO_CONNECT, m_btnConnect);
	DDX_Control(pDX, IDC_DEMO_TEMP_REAL, m_chkTempRealtime);
	DDX_Control(pDX, IDC_DEMO_TEMP_LOG, m_chkTempLog);
	DDX_Control(pDX, IDC_DEMO_TEMP_LOG_ACQUIRE, m_btnAcquireTempData);
}

BEGIN_MESSAGE_MAP(CTabDemo, CTabDlg)
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_DEMO_TEMP_REAL, &CTabDemo::OnBnClickedDemoTempReal)
	ON_BN_CLICKED(IDC_DEMO_TEMP_LOG, &CTabDemo::OnBnClickedDemoTempLog)
	ON_BN_CLICKED(IDC_DEMO_CONNECT, &CTabDemo::OnBnClickedDemoConnect)
	ON_CBN_SELCHANGE(IDC_DEMO_COMBO, &CTabDemo::OnCbnSelchangeDemoCombo)
	ON_CBN_DROPDOWN(IDC_DEMO_COMBO, &CTabDemo::OnCbnDropdownDemoCombo)
	ON_BN_CLICKED(IDC_DEMO_TEMP_LOG_ACQUIRE, &CTabDemo::OnBnClickedDemoTempLogAcquire)
	ON_BN_CLICKED(IDC_DEMO_UNIT_C, &CTabDemo::OnBnClickedDemoUnitC)
	ON_BN_CLICKED(IDC_DEMO_UNIT_F, &CTabDemo::OnBnClickedDemoUnitF)
END_MESSAGE_MAP()

// CTabDemo message handlers

BOOL CTabDemo::OnInitDialog()
{
	CTabDlg::OnInitDialog();

	// TODO:  Add extra initialization here
	m_PotValueDial.CreateFromAlias(this, IDC_DEMO_POTVALUEDIAL);
	m_TempGraph.CreateFromAlias(this, IDC_DEMO_TEMPGRAPH);

	SetTempMode(TRUE);
	ShowCelsius(true);
	EnableControls(false);
	OnCbnSelchangeDemoCombo();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CTabDemo::OnTimer(UINT_PTR nIDEvent)
{
	static bool s_fInTimer = false;
	if(!s_fInTimer)
	{
		s_fInTimer = true;

		bool fError = false;
		// Read the temperature if Real Time Mode is enabled.
		if (m_fRealtimeTemp)
		{
			WORD wTemperature;
			if(theApp.m_DeviceMgr.ReadTemperature(wTemperature))
				ProcessTemperature(wTemperature);
			else
				fError = true;
		}

		if(!fError)
		{
			// Read the POT Value
			WORD wPot;
			if(theApp.m_DeviceMgr.ReadPot(wPot))
				ProcessPOT(wPot);
			else
				fError = true;
		}

		// Set the LED Status
		// NOTE: The LED states are sent to the board on every timer.
		// A more efficient design would be to only send the info when 
		//   the user changes the state (ie. clicks on an LED), but the 
		//   send-on-every-timer method is how the original code did it, 
		//   so I left it as-is. It's just a demo :)
		if(!fError)
			fError = !theApp.m_DeviceMgr.UpdateLED(3,m_led3.IsOn());
		if(!fError)
			fError = !theApp.m_DeviceMgr.UpdateLED(4,m_led4.IsOn());

		if(fError)
			Connect(false);

		s_fInTimer = false;
	}

	CTabDlg::OnTimer(nIDEvent);
}

int CTabDemo::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CTabDlg::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here
//	SetTimer(100, 1000, NULL);



	return 0;
}

void CTabDemo::OnBnClickedDemoTempReal()
{
	SetTempMode(TRUE);
}

void CTabDemo::OnBnClickedDemoTempLog()
{
	SetTempMode(FALSE);
}

void CTabDemo::OnBnClickedDemoConnect()
{
	Connect(IsButtonShowingConnect());
}

void CTabDemo::ShowConnect(bool fConnect)
{
	m_btnConnect.SetWindowText(fConnect?CONNECTBTN_TEXT_CONNECT:CONNECTBTN_TEXT_DISCONNECT);
}

bool CTabDemo::IsButtonShowingConnect()
{
	CString sCaption;
	m_btnConnect.GetWindowText(sCaption);
	return (sCaption == CONNECTBTN_TEXT_CONNECT);
}

void CTabDemo::OnCbnSelchangeDemoCombo()
{
	int nSel = m_comboChannel.GetCurSel();
	m_btnConnect.EnableWindow(nSel >= 0);
	if (nSel >= 0)
	{
		if(IsButtonShowingConnect() && m_fAutoConnect)
			Connect(true);
	}
	else
	{
		ShowConnect(true);
	}
}

void CTabDemo::OnCbnDropdownDemoCombo()
{
	theApp.m_DeviceMgr.Refresh();
	m_comboChannel.ResetContent();
	theApp.m_DeviceMgr.FillDeviceCombo(m_comboChannel);
}

static CString IntToStr(int i)
{
	CString s;
	s.Format("%d", i);
	return s;
}

void CTabDemo::OnBnClickedDemoTempLogAcquire()
{
	CByteBuf bbData;

    m_btnAcquireTempData.EnableWindow(false);

    // Read the temperature log
	if(theApp.m_DeviceMgr.ReadTempLogging(bbData))
	{
		int n = bbData.GetCount();
		if(n > 0)
		{
			if(!(n&1))
			{
				for(int i=0; i<n; i+=2)
				{
					WORD wTemp = MAKEWORD(bbData[i], bbData[i+1]);
					theApp.ShowMessage("Temperature Point "+IntToStr(i/2)+" : " +ProcessTemperature(wTemp));
				}
			}
			else
			{
				theApp.ShowWarning("Odd # of bytes acquired.");
			}
		}
		else
		{
			theApp.ShowWarning("No data acquired.");
		}
	}

    m_btnAcquireTempData.EnableWindow(true);
}

void CTabDemo::OnBnClickedDemoUnitC()
{
	ShowCelsius(true);
}

void CTabDemo::OnBnClickedDemoUnitF()
{
	ShowCelsius(false);
}
