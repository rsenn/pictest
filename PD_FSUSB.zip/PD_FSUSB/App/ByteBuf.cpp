// ByteBuf.cpp : implementation file
//

#include "stdafx.h"
#include "ByteBuf.h"

#ifdef __AFX_H__
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif


/////////////////////////////////////////////////////////////////////////////
// CByteBuf

BBDATA s_bbNil; 

CByteBuf::CByteBuf(DWORD dwSize) :
	m_pData(NULL)
{
	SetSize(dwSize);
}

CByteBuf::CByteBuf(const CByteBuf& bbInit) :
	m_pData(NULL)
{
	if(bbInit.GetCount() > 0)
	{
		ASSERT(bbInit._get_data()->nRefs != 0);
		if (bbInit._get_data()->nRefs >= 0)
		{
			ASSERT(!bbInit._is_nil_data());
			m_pData = bbInit.m_pData;
			m_pData->AddRef();
		}
	}
}

CByteBuf::CByteBuf(LPCBYTE pbInit, DWORD dwCount) :
	m_pData(NULL)
{
	_assign_data(pbInit, dwCount);
}

CByteBuf::~CByteBuf()
{
	_release_data();
}

void CByteBuf::_release_data()
{
	if(!_is_nil_data())
	{
		if (m_pData->DecRef() <= 0)
		{
			delete m_pData;
			m_pData = NULL;
		}
	}
}

BOOL CByteBuf::_is_nil_data() const
{
	return (_get_data() == &s_bbNil);
}

BBDATAPTR CByteBuf::_get_data() const
{
	if(m_pData)
		return m_pData;
	return &s_bbNil;
}

const CByteBuf& CByteBuf::operator=(const CByteBuf& bbSrc)
{
	if (m_pData != bbSrc.m_pData)
	{
		if ((_get_data()->nRefs < 0 && _get_data() != &s_bbNil) || bbSrc._get_data()->nRefs < 0)
		{
			// actual copy necessary since one of the strings is locked
			_assign_data(bbSrc.m_pData->pb, bbSrc.m_pData->sz);
		}
		else
		{
			// can just copy references around
			_release_data();
			ASSERT(bbSrc._get_data() != &s_bbNil);
			m_pData = bbSrc.m_pData;
			m_pData->AddRef();
			//InterlockedIncrement(&_get_data()->nRefs);
		}
	}
	return *this;
}

const CByteBuf& CByteBuf::operator+=(const CByteBuf& bbSrc)
{
	LPCBYTE pb = bbSrc;
	int n = bbSrc.GetCount();
	return Append(pb, n);
}

const CByteBuf& CByteBuf::operator+=(BYTE b)
{
	return Append(&b, 1);
}

const CByteBuf& CByteBuf::Append(LPCBYTE pbAppend, DWORD dwCount)
{
	if(m_pData)
	{
		ASSERT(1 == m_pData->nRefs);
		int newSz = m_pData->sz+dwCount;
		LPBYTE pbNew = new BYTE[newSz];
		ASSERT(pbNew);
		if(pbNew)
		{
			memcpy(pbNew, m_pData->pb, m_pData->sz);
			memcpy(pbNew+m_pData->sz, pbAppend, dwCount);
			_assign_data(pbNew, newSz);
			delete [] pbNew;
		}
	}
	else
	{
		_assign_data(pbAppend, dwCount);
	}

	return *this;
}

void CByteBuf::SetData(LPCBYTE pbData, DWORD dwCount)
{
	_assign_data(pbData, dwCount);
}

void CByteBuf::SetSize(DWORD dwLen)
{
	LPBYTE pb = new BYTE[dwLen];
	memset(pb, 0, dwLen);
	_assign_data(pb, dwLen);
	delete [] pb;
}

void CByteBuf::_assign_data(LPCBYTE pb, DWORD sz)
{
	LPBYTE pbTemp = _dup_data(pb, sz);// In case pb points to m_pData->pb
	_release_data();
	m_pData = new BBDATA;
	if(m_pData)
	{
		m_pData->AddRef();
		m_pData->pb = pbTemp;
		pbTemp = NULL;
		m_pData->sz = sz;
	}
	delete [] pbTemp;
}

BYTE CByteBuf::GetAt(int idx) const
{
	ASSERT(m_pData);
	ASSERT(m_pData->pb);
	ASSERT(idx >= 0);
	ASSERT(idx < m_pData->sz);
	return m_pData->pb[idx];
}

LPBYTE CByteBuf::_dup_data(LPCBYTE pb, DWORD sz)
{
	LPBYTE pbDup = NULL;
	if(pb && (sz>0))
	{
		pbDup = new BYTE[sz];
		memcpy(pbDup, pb, sz);
	}
	return pbDup;
}

