#pragma once

class CDisabledImage :
	public CImage
{
public:
	CDisabledImage(void);
	~CDisabledImage(void);

	void SwapBitmapColor(int ColorOld, int ColorNew);
	void PreserveBitmapColor(int ColorSave, int ColorNew);
	void ConvertColors(COLORREF crTarget, COLORREF* pcrSwap, int nSwap, int nClrIndex);
};
