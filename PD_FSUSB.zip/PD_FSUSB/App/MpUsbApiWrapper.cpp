#include "StdAfx.h"
#include "PD_FSUSB.h"
#include "MPUSBAPIWrapper.h"
#include <winioctl.h>
#include <initguid.h>
#include "..\MPUSBAPI\Ioctls.h"	//GUID_DEVINTERFACE_MCHPUSB

CMpUsbApiWrapper::CMpUsbApiWrapper(void)
{
	m_pfnMPUSBGetDLLVersion = 
	m_pfnMPUSBGetDeviceCount = 
	m_pfnMPUSBOpen = 
	m_pfnMPUSBRead = 
	m_pfnMPUSBWrite = 
	m_pfnMPUSBReadInt = 
	m_pfnMPUSBClose = NULL;

	char szDll[MAX_PATH] = {0};
	::GetModuleFileName(NULL, szDll, sizeof(szDll));
	LPSTR psFile = strrchr(szDll, '\\');
	if(psFile)
		lstrcpy(psFile+1, "mpusbapi.dll");
	m_hLib = LoadLibrary(szDll);
	if(m_hLib)
	{
		m_pfnMPUSBGetDLLVersion = GetProcAddress(m_hLib, "_MPUSBGetDLLVersion");
		m_pfnMPUSBGetDeviceCount = GetProcAddress(m_hLib, "_MPUSBGetDeviceCount");
		m_pfnMPUSBOpen = GetProcAddress(m_hLib, "_MPUSBOpen");
		m_pfnMPUSBRead = GetProcAddress(m_hLib, "_MPUSBRead");
		m_pfnMPUSBWrite = GetProcAddress(m_hLib, "_MPUSBWrite");
		m_pfnMPUSBReadInt = GetProcAddress(m_hLib, "_MPUSBReadInt");
		m_pfnMPUSBClose = GetProcAddress(m_hLib, "_MPUSBClose");
	}
	else
	{
		AfxMessageBox(FmtStr("Failed to load:\n%s\n\nAll functionality will be disabled", szDll), MB_OK|MB_ICONEXCLAMATION);
	}
}

CMpUsbApiWrapper::~CMpUsbApiWrapper(void)
{
	m_pfnMPUSBGetDLLVersion = 
	m_pfnMPUSBGetDeviceCount = 
	m_pfnMPUSBOpen = 
	m_pfnMPUSBRead = 
	m_pfnMPUSBWrite = 
	m_pfnMPUSBReadInt = 
	m_pfnMPUSBClose = NULL;

	FreeLibrary(m_hLib);
}

DWORD CMpUsbApiWrapper::GetDLLVersion(void)
{
	DWORD dwVer = 0;
	if(m_pfnMPUSBGetDLLVersion)
		dwVer = ((PFN_MPUSBGetDLLVersion)m_pfnMPUSBGetDLLVersion)();
	return dwVer;
}

DWORD CMpUsbApiWrapper::GetDeviceCount(PCHAR pVID_PID)
{
	DWORD dwCount = 0;
	if(m_pfnMPUSBGetDeviceCount)
		dwCount = ((PFN_MPUSBGetDeviceCount)m_pfnMPUSBGetDeviceCount)(pVID_PID);
	return dwCount;
}

HANDLE CMpUsbApiWrapper::Open(IN DWORD instance, IN PCHAR pVID_PID, IN PCHAR pEP, IN DWORD dwDir, IN DWORD dwReserved)
{
	HANDLE hdl = INVALID_HANDLE_VALUE;
	if(m_pfnMPUSBOpen)
		hdl = ((PFN_MPUSBOpen)m_pfnMPUSBOpen)(instance, pVID_PID, pEP, dwDir, 0);
	return hdl;
}

DWORD CMpUsbApiWrapper::Read(IN HANDLE handle, IN PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds)
{
	DWORD dwResult = MPUSB_FAIL;
	if(m_pfnMPUSBRead)
		dwResult = ((PFN_MPUSBRead)m_pfnMPUSBRead)(handle, pData, dwLen, pLength, dwMilliseconds);
    return dwResult;
}

DWORD CMpUsbApiWrapper::Write(IN HANDLE handle, IN PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds)
{
    DWORD dwResult = MPUSB_FAIL;
	if(m_pfnMPUSBWrite)
		dwResult = ((PFN_MPUSBWrite)m_pfnMPUSBWrite)(handle, pData, dwLen, pLength, dwMilliseconds);
    return dwResult;
}

DWORD CMpUsbApiWrapper::ReadInt(IN HANDLE handle, PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds)
{
    DWORD dwResult = MPUSB_FAIL;
	if(m_pfnMPUSBReadInt)
		dwResult = ((PFN_MPUSBReadInt)m_pfnMPUSBReadInt)(handle, pData, dwLen, pLength, dwMilliseconds);
	return dwResult;
}

BOOL CMpUsbApiWrapper::Close(IN HANDLE handle)
{
	BOOL rslt = FALSE;
	if(m_pfnMPUSBClose)
		rslt = ((PFN_MPUSBClose)m_pfnMPUSBClose)(handle);
	return rslt;
}
