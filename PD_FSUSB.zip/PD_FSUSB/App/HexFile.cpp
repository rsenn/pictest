/* I N C L U D E S **********************************************************/
//---------------------------------------------------------------------------
#include "stdafx.h"
#include "PD_FSUSB.h"
#include "HexFile.h"

static BYTE atox(LPSTR& psLine)
{
	BYTE b = 0;
	if((*psLine>='0')&&(*psLine<='9'))
		b = *psLine-'0';
	else if((*psLine>='a')&&(*psLine<='f'))
		b = *psLine-'a'+10;
	else if((*psLine>='A')&&(*psLine<='F'))
		b = *psLine-'A'+10;
	psLine++;
	return b;
}
static BYTE getbyte(LPSTR& psLine, DWORD& dwChecksum)
{
	BYTE h = atox(psLine);
	BYTE l = atox(psLine);
	BYTE b = ((h<<4)&0xF0)|(l&0x0f);
	dwChecksum += b;
	return b;
}

//**************************************
// CHexFile class
//**************************************

CHexFile::CHexFile() : 
	m_mgPgm(MG_PGM),
	m_mgUID(MG_UID), 
	m_mgCfg(MG_CFG), 
	m_mgDevID(MG_DEVID),
	m_mgEE(MG_EE), 
	m_fValid(false)	
{
}
CHexFile::~CHexFile()
{
	Empty();
}

void CHexFile::Empty()
{
	m_mgPgm.Empty();
	m_mgEE.Empty();
	m_mgUID.Empty();
	m_mgCfg.Empty();
	m_mgDevID.Empty();

	m_fValid = false;
}

bool CHexFile::IsEmpty()
{
	if(!m_mgPgm.IsEmpty())
		return false;
	if(!m_mgEE.IsEmpty())
		return false;
	if(!m_mgUID.IsEmpty())
		return false;
	if(!m_mgCfg.IsEmpty())
		return false;
	if(!m_mgDevID.IsEmpty())
		return false;
	return true;
}

// Helper for ImportP18HEXFile()
class CHexfileLineParser
{
public:
	CHexfileLineParser(LPCSTR psLine);
	~CHexfileLineParser()	{}
	WORD wAddr;
	BYTE bRectype;
	CByteBuf bbData;
	bool fValid;
	CString sParseError;
};
static BYTE getnibble(LPCSTR ps)
{
	BYTE b = 0;
	if((*ps>='0')&&(*ps<='9'))
		b = *ps-'0';
	else if((*ps>='a')&&(*ps<='f'))
		b = *ps-'a'+10;
	else if((*ps>='A')&&(*ps<='F'))
		b = *ps-'A'+10;
	return b;
}
static BYTE makebyte(LPCSTR& ps, DWORD& dwChksum)
{
	BYTE h = getnibble(ps++);
	BYTE l = getnibble(ps++);
	BYTE b = ((h<<4)&0xF0)|(l&0x0f);
	dwChksum += b;
	return b;
}
CHexfileLineParser::CHexfileLineParser(LPCSTR psLine) :
	wAddr(-1),
	bRectype(-1),
	fValid(false)
{
	// Each line must have AT LEAST ":LLAAAACCSS" (no data, LL=00)
	CString sLine(psLine);
	int linelen = sLine.GetLength();
	if( (linelen>=11) && (linelen&1))
	{
		LPCSTR psTemp = sLine;
		if(':'==*psTemp)
		{
			psTemp++;
			DWORD dwChksum = 0;
			BYTE datalen = makebyte(psTemp, dwChksum);
			BYTE haddr = makebyte(psTemp, dwChksum);
			BYTE laddr = makebyte(psTemp, dwChksum);
			this->wAddr = MAKEWORD(laddr, haddr);
			this->bRectype = makebyte(psTemp, dwChksum);

			if( (HRT_DATA==this->bRectype) || 
				(HRT_EOF==this->bRectype) || 
				(HRT_EXTSEG==this->bRectype) || 
				(HRT_STARTSEG==this->bRectype) || 
				(HRT_EXTLINADDR==this->bRectype) || 
				(HRT_STARTLINADDR==this->bRectype) )
			{
				if(lstrlen(psTemp) == (2*datalen+2)) // 2 chars per data byte, plus 2 more for the chksum
				{
					for(int z=0; z<datalen; z++)
						this->bbData += makebyte(psTemp, dwChksum);
					makebyte(psTemp, dwChksum);	// Just accumulate dwChksum

					this->fValid = !(dwChksum&0xFF);
					if(!this->fValid)
					{
						this->sParseError = "Invalid checksum";
						ASSERT(0);
					}
				}
				else
				{
					this->sParseError = "Invalid data length";
					ASSERT(0);
				}
			}
			else
			{
				this->sParseError = "Invalid record type";
				ASSERT(0);
			}
		}
		else
		{
			this->sParseError = "Invalid line format";
			ASSERT(0);
		}
	}
	else
	{
		// Must be at least 11 chars and odd-length (the colon plus n two-char nibbles)
		this->sParseError = "Invalid line length";
		ASSERT(0);
	}
}

// Intel HEX file format: http://en.wikipedia.org/wiki/Intel_HEX
// Also useful: http://www.8052.com/tutintel.phtml
// This fcn does the parsing in several small steps.
// Slower to execute, but easier to follow, thus better for a demo.
bool CHexFile::ImportP18HEXFile(LPCSTR psFile)
{
	Empty();

	// Step 1:	Load the (text) file and parse each line into an array
	CStringArray saLines;
	FILE *fp = fopen(psFile, "rb");
	if (fp) 
	{
		fseek(fp, 0, SEEK_END);
		long len = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		if(len > 0)
		{
			char* data = new char[len+2];
			if(data)
			{
				memset(data, 0, len+2);
				if(len == fread(data, sizeof(char), len, fp))
				{
					// Ensure final line ends in a newline (parsing code below expects it)
					if('\n' != data[len-1])
						data[len] = '\n';

					int nLine = 0;
					char* psLine = data;
					while(psLine && *psLine)
					{
						char* psNext = strchr(psLine, '\n');
						if(psNext)
						{
							*psNext = 0;
							psNext++;
						}
						// Clean up the EOL
						char* psCr = strchr(psLine, '\r');
						if(psCr)
							*psCr = 0;

						saLines.Add(psLine);
						psLine = psNext;
					}
				}
				delete [] data;
			}
		}
		fclose(fp);
	}

	// Step 2: Parse the lines into the Mem Groups.
	// Each line must have the format ":LLAAAACC<data>SS"
	// Where:
	//	1st char is a colon
	//  Everything afterward are 2-hex-char (high-nibble/low-nibble) representations of bytes, eg. "12"==0x12
	//	Those bytes are:
	//		LL is the length
	//		AAAA is the address
	//		CC is the record type (HEXRECTYPE)
	//		<data> is 'LL' of data bytes
	//		SS is the checksum
	// The line sequence is:
	//		An Address record (HRT_EXTSEG, HRT_STARTSEG, HRT_EXTLINADDR, HRT_STARTLINADDR)
	//		Any number of Data records (HRT_DATA)
	//		Either:
	//			An EOF record, or
	//			Another Address record (with attendant data records)
	int nLine = 0;
	bool fError = false;
	bool fEOF = false;
	CHexMemGroup* pCurrGrp = NULL;
	while(!fError && !theApp.m_DeviceMgr.m_fAbortOperation && !fEOF && (nLine<saLines.GetSize()) )
	{
		if(!(nLine&0xff))
			theApp.ProcessMessages();

		CString sLine = saLines.GetAt(nLine++);
		if(!sLine.IsEmpty())	// Skip empty lines; not an error
		{
			CHexfileLineParser lp(sLine);
			if(lp.fValid)
			{
				switch(lp.bRectype)
				{
					case HRT_DATA:
						if(pCurrGrp)
						{
							fError = !pCurrGrp->Add(lp.wAddr, lp.bbData);
						}
						else
						{
							theApp.ShowWarning(FmtStr("Data w/o EXTLINADDR, line %d", nLine-1));
							fError = true;
						}
						break;
					case HRT_EOF:
						fEOF = true;
						break;
					case HRT_EXTSEG:
						theApp.ShowWarning(FmtStr("Unhandled EXTSEG, line %d", nLine-1));
						fError = true;
						break;
					case HRT_STARTSEG:
						theApp.ShowWarning(FmtStr("Unhandled STARTSEG, line %d", nLine-1));
						fError = true;
						break;
					case HRT_EXTLINADDR:
						if(2 == lp.bbData.GetCount())
						{
							// The 2-byte data of the EXTLINADDR is the group ID
//							MEMGRP mg = (MEMGRP)MAKEWORD(lp.bbData[1], lp.bbData[0]);
							MEMGRP mg = GetGroupID(MAKEWORD(lp.bbData[1], lp.bbData[0]));
							pCurrGrp = GetGroup(mg);
							if(!pCurrGrp)
							{
								theApp.ShowWarning(FmtStr("Invalid EXTLINADDR ID, line %d", nLine-1));
								fError = true;
							}
						}
						break;
					case HRT_STARTLINADDR:
						break;
				}
			}
			else
			{
				theApp.ShowWarning(lp.sParseError);
				fError = true;
			}
		}
	}

	if(theApp.m_DeviceMgr.m_fAbortOperation)
	{
		this->Empty();
		fError = true;
	}

	m_fValid = !fError;
	return IsValid();
}

MEMGRP CHexFile::GetGroupID(WORD wAddress)
{
	MEMGRP mg = MG_UNKNOWN;

	CHexMemGroup* pmg = NULL;
	switch(wAddress)
	{
		case MG_PGM:
		case MG_UID:
		case MG_CFG:
		case MG_DEVID:
		case MG_EE:
			mg = (MEMGRP)wAddress;
			break;
		default:
			if( (MG_PGM<=wAddress) && (MG_UID>wAddress) )
				mg = MG_PGM;
			else
				ASSERT(0);
			break;
	}
	return mg;
}

CHexMemGroup* CHexFile::GetGroup(MEMGRP mg)
{
	CHexMemGroup* pmg = NULL;
	switch(mg)
	{
		case MG_PGM:	pmg = &m_mgPgm;		break;
		case MG_UID:	pmg = &m_mgUID;		break;
		case MG_CFG:	pmg = &m_mgCfg;		break;
		case MG_DEVID:	pmg = &m_mgDevID;	break;
		case MG_EE:	pmg = &m_mgEE;		break;
	}
	ASSERT(pmg);
	return pmg;
}
void CHexFile::SetGroupData(MEMGRP mg, CByteBuf& data)
{
	CHexMemGroup* pmg = GetGroup(mg);
	if(pmg)
	{
		pmg->Empty();
		WORD wBaseAddr = CHexMemGroup::GetGroupOffsetBaseAddr(mg);
		AddGroupData(mg, wBaseAddr, data);
	}
}
void CHexFile::AddGroupData(MEMGRP mg, WORD wRelAddr, CByteBuf& data)
{
	CHexMemGroup* pmg = GetGroup(mg);
	if(pmg)
		pmg->Add(wRelAddr, data);
}

// Mem listings are formatted as follows:
// <<6-digit HEX Address><Space><2-digit HEX Data1>...<Space><2-digit HEX Data16><\r\n>
CString CHexFile::GetGroupListing(MEMGRP mg)
{
	CString sListing;
	CHexMemGroup* pmg = GetGroup(mg);
	if(pmg)
	{
		WORD wSeg = CHexMemGroup::GetGroupSegmentAddr(mg);
		DWORD dwBase = CHexMemGroup::GetGroupOffsetBaseAddr(mg);
		MEMBLOCKENUM mbe;
		while(pmg->EnumBlocks(mbe))
		{
			for(int b=0; b<mbe.pmb->m_data.GetCount(); b++)
			{
				if(!(b&0x0F))
					sListing += FmtStr("\r\n%02X%04X ", wSeg, dwBase+b);
				sListing += FmtStr(" %02X", mbe.pmb->m_data[b]);
			}
		}
	}

	sListing.TrimLeft("\r\n");
	return sListing;
}

static CString BuildHexfileLine(WORD wAddr, HEXRECTYPE hrt, CByteBuf& bbData, int nDataStart=0, int nMaxCount=-1)
{
	CString sLine;

	int nCount = bbData.GetCount();
	if( (nMaxCount>=0) && (nMaxCount<nCount) )
		nCount = nMaxCount;
	ASSERT(nCount <= 0xFF);
	BYTE bCount = (BYTE)nCount;

	BYTE bRectype = (BYTE)hrt;
	sLine += FmtStr(":%02X%04X%02X", bCount, wAddr, bRectype);

	BYTE bCS = bCount;
	bCS += LOBYTE(wAddr);
	bCS += HIBYTE(wAddr);
	bCS += bRectype;

	int nEnd = nDataStart+bCount;
	for(int d=nDataStart; d<nEnd; d++)
	{
		bCS += bbData[d];
		sLine += FmtStr("%02X", bbData[d]);
	}

	sLine += FmtStr("%02X\r\n", (0x100-(bCS&0xFF))&0xFF);

	return sLine;
}
static CString BuildHexfileLine(WORD wGrpAddr, HEXRECTYPE hrt, WORD wBlkAddr)
{
	CByteBuf bbData;
	bbData += HIBYTE(wBlkAddr);
	bbData += LOBYTE(wBlkAddr);
	return BuildHexfileLine(wGrpAddr, hrt, bbData);
}
// Saves data to the given filename in Intel HEX format
bool CHexFile::ExportP18HEXFile(LPCSTR psFileName)
{
	bool fOK = true;
	CString sOut;	// We'll write this to the file

	// These are the groups we'll write, in the sequence we'll write them
	MEMGRP grps[] = {MG_PGM, MG_EE, MG_CFG, MG_UID};
	// Note that we don't write DeviceID memory to the file: that was burned into the device at manufacture time
	int nGrps = sizeof(grps)/sizeof(grps[0]);
	for(int g=0; fOK && (g<nGrps); g++)
	{
		CHexMemGroup* pmg = GetGroup(grps[g]);
		if(pmg)
		{
			WORD wGrpSegAddr = pmg->GetGroupSegmentAddr();
			WORD wGrpBaseAddr = pmg->GetGroupOffsetBaseAddr();
			MEMBLOCKENUM mbe;
			while(pmg->EnumBlocks(mbe))
			{
				WORD wBlkBaseAddr = mbe.pmb->m_wBaseAddr;
				for(int d=0; d<mbe.pmb->m_data.GetCount(); d+=0x10)
				{
					if(!(d&0xFFFF))
					{
						// The address range is 0xFFFF (64k), so we need to write a new EXTLINADDR line each time
						//    we cross a 64k boundary. This includes the case for the very 1st data line (addr=0).
						CString sAddrLine = BuildHexfileLine(wGrpBaseAddr, HRT_EXTLINADDR, wGrpSegAddr+(d>>16));
						sOut += sAddrLine;
					}
					sOut += BuildHexfileLine(((wBlkBaseAddr+d)&0xFFFF), HRT_DATA, mbe.pmb->m_data, d, 0x10);
				}
			}
		}
		else
		{
			fOK = false;
			break;
		}
	}

	if(fOK)
	{
		// Add the EOF line
		CByteBuf bbEmpty;
		sOut += BuildHexfileLine(0, HRT_EOF, bbEmpty);

		CFile fOut;
		if(fOut.Open(psFileName,CFile::modeCreate|CFile::modeWrite))
		{
			fOut.Write(sOut, sOut.GetLength());
		}
		else
		{
			fOK = false;
		}
	}

	return fOK;
}
