// FixedFontEdit.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "FixedFontEdit.h"


// CFixedFontEdit

IMPLEMENT_DYNAMIC(CFixedFontEdit, CEdit)

CFixedFontEdit::CFixedFontEdit()
{

}

CFixedFontEdit::~CFixedFontEdit()
{
}


BEGIN_MESSAGE_MAP(CFixedFontEdit, CEdit)
END_MESSAGE_MAP()



// CFixedFontEdit message handlers



void CFixedFontEdit::PreSubclassWindow()
{
	// TODO: Add your specialized code here and/or call the base class
//	HFONT hf = (HFONT)GetStockObject(ANSI_FIXED_FONT);
//	CFont* pf = CFont::FromHandle(hf);
//	LOGFONT logFont;
//	pf->GetLogFont(&logFont);

	m_font.CreatePointFont(100, "Courier New");
	this->SetFont(&m_font);

//	SendMessage(WM_SETFONT, (WPARAM)hf, 0);

	CEdit::PreSubclassWindow();
}
