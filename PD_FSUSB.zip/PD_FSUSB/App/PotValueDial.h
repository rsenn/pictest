#pragma once

#include "BmpCtrl.h"

// CPotValueDial

class CPotValueDial : public CBmpCtrl
{
	DECLARE_DYNAMIC(CPotValueDial)

public:
	CPotValueDial();
	virtual ~CPotValueDial();

	void SetValue(int nValue);

protected:
	int m_nValue;
	DECLARE_MESSAGE_MAP()

	virtual void PostPaintBg(CPaintDC& dc);

public:
	afx_msg void OnEnable(BOOL bEnable);
};
