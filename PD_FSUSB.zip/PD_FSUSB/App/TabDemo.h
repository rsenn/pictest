#pragma once
#include "afxwin.h"
#include "TabDlg.h"
#include "potvaluedial.h"
#include "led.h"
#include "tempgraph.h"
#include "fixedfontedit.h"


// CTabDemo dialog

class CTabDemo : public CTabDlg
{
	DECLARE_DYNAMIC(CTabDemo)

public:
	CTabDemo();
	virtual ~CTabDemo();

	virtual void Activate(bool fActivate);
	virtual void SetAutoConnect(bool fAuto);

// Dialog Data
	enum { IDD = IDD_TAB_DEMO };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
protected:
	BOOL m_fRealtimeTemp;
	void SetTempMode(BOOL fRealtime);
	CString ProcessTemperature(WORD wTemperature);
	void ProcessPOT(WORD wPot);
	void Connect(bool fConnect);
	void EnableControls(bool fEnable);
	void EnableTimer(bool fEnable);
	void ResetMode(PDMODE mode);
	void ShowConnect(bool fConnect);
	bool IsButtonShowingConnect();
	void ShowCelsius(bool fCelsius);
	
public:
	CPotValueDial m_PotValueDial;
	CLed m_led3, m_led4;
	CTempGraph m_TempGraph;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL OnInitDialog();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	CFixedFontEdit m_editTempVal;
	CFixedFontEdit m_editPotRes;
	afx_msg void OnBnClickedDemoTempReal();
	afx_msg void OnBnClickedDemoTempLog();
	afx_msg void OnBnClickedDemoConnect();
	CComboBox m_comboChannel;
	CButton m_btnConnect;
	CButton m_chkTempRealtime;
	CButton m_chkTempLog;
	afx_msg void OnCbnSelchangeDemoCombo();
	CButton m_btnAcquireTempData;
	afx_msg void OnCbnDropdownDemoCombo();
	afx_msg void OnBnClickedDemoTempLogAcquire();
	afx_msg void OnBnClickedDemoUnitC();
	afx_msg void OnBnClickedDemoUnitF();
};
