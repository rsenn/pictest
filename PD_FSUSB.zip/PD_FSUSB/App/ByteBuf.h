// ByteBuf.h : header file
//

#pragma once

#define ARRAYSZ(ra)		(sizeof(ra)/sizeof(ra[0]))
typedef CONST BYTE *LPCBYTE;

/////////////////////////////////////////////////////////////////////////////
// CByteBuf class

extern struct BBDATA s_bbNil;

struct BBDATA
{
	LPBYTE pb;
	int sz;
	long nRefs;

	BBDATA(): pb(NULL), sz(0), nRefs(0)	{}
	~BBDATA()
	{
		ASSERT(nRefs<1); 
		delete pb;
	}
	long AddRef()
	{
		return InterlockedIncrement(&nRefs);
	}
	long DecRef()
	{
		ASSERT(nRefs < 10);
		ASSERT(nRefs > 0);
		return InterlockedDecrement(&nRefs);
	}
};
typedef BBDATA*		BBDATAPTR;

class CByteBuf
{
public:
	CByteBuf(DWORD dwSize=0);
	CByteBuf(const CByteBuf& bbInit);
	CByteBuf(LPCBYTE pbInit, DWORD dwCount);
	virtual ~CByteBuf();

	const CByteBuf& operator=(const CByteBuf& bbSrc);
	const CByteBuf& operator+=(const CByteBuf& bbSrc);
	const CByteBuf& operator+=(BYTE b);
	const CByteBuf& Append(LPCBYTE pbAppend, DWORD dwCount);

	void Empty()	{_release_data();}

	void SetData(LPCBYTE pbData, DWORD dwCount);
	void SetSize(DWORD dwLen);

	operator LPCBYTE() const	{return GetData();}
	LPCBYTE GetData() const;

	int GetCount() const;

	BYTE GetAt(int idx) const;
	BYTE operator[](int idx) const	{return GetAt(idx);}

protected:
	BBDATAPTR m_pData;

	BBDATAPTR _get_data() const;
	void _assign_data(LPCBYTE pb, DWORD sz);
	void _release_data();
	LPBYTE _dup_data(LPCBYTE pb, DWORD sz);
	BOOL _is_nil_data() const;
};

inline LPCBYTE CByteBuf::GetData() const
//inline CByteBuf::operator LPCBYTE() const
{
	if(m_pData) return m_pData->pb; 
	return NULL;
}

inline int CByteBuf::GetCount() const
{
	if(m_pData) return m_pData->sz; 
	return 0;
}

