#pragma hdrstop
/* I N C L U D E S **********************************************************/
//---------------------------------------------------------------------------
#include "stdafx.h"
#include "PD_FSUSB.h"
#include "DeviceManager.h"

/** V A R I A B L E S ********************************************************/
//---------------------------------------------------------------------------
int CDemoBoard::m_nUsedDevIDs[4] = {0,0,0,0};
HINSTANCE libHandle;

// Memory reads/writes are initiated by sending a 5-byte value
// I could just use BYTE[5], but this demo I used a struct for field clarity.
// This fcn inits that "command header"
struct MEMCMDHDR
{
	BYTE cmd;
	BYTE len;
	struct
	{
		BYTE lo;	// Low   address byte ......XX
		BYTE hi;	// High  address byte ....XX..
		BYTE up;	// Upper address byte ..XX....
					// Top   address byte XX...... isn't used
	}addr;
};


static DWORD LogUsbError(LPCSTR psErr)
{
	DWORD dwError = ::GetLastError();
    char* lpMsgBuf=NULL;

	::FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        dwError,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,0, NULL );
	CString sMsg(lpMsgBuf);
	LocalFree(lpMsgBuf);

	sMsg.TrimRight("\r\n");
	CString str = FmtStr("%s: error(%d) msg(%s)",psErr,dwError,sMsg);

	theApp.ShowWarning(str);
    //MessageBox(NULL, str , "Error", MB_OK|MB_SYSTEMMODAL);

    return dwError;
}

//******************************************************************************
//******************************************************************************
// CDemoBoard class

CDemoBoard::CDemoBoard(LPCSTR psDeviceName, PDMODE mode, int assignedIndex) :
    m_sDeviceName(psDeviceName),
    m_mode(mode),
	m_usb(assignedIndex),
    m_nAssignedIndex(assignedIndex),
    m_fDisabled(false)
{
    if (PDMODE_DEMO == m_mode ) // Demo Mode
    {
        // Assign appropriate ID
        // There can be a maximum of 4 devices
        int i;
        for (i = 0; i < 4; i++)
        {
            if (m_nUsedDevIDs[i] == 0) 
			{
                m_nDemoDevID = i;
                m_nUsedDevIDs[i] = 0x1;
                break;
            }
        }
        if (i == 4) 
		{
            // No place exists for this device to make a connection.
            m_nDemoDevID = -1;
			m_sDeviceName.Insert(0, "DISABLED - ");
            m_fDisabled = true;
        }
    }
}

CDemoBoard::~CDemoBoard()
{
  if (PDMODE_DEMO == m_mode) //Demo Mode
        m_nUsedDevIDs[m_nDemoDevID] = 0;
}

// Opens the communication channel
bool CDemoBoard::Open()
{                            
	if (m_fDisabled) 
		return false;
	return m_usb.Open(m_mode);
}

// Closes previously opened device.
void CDemoBoard::Close()
{
    if (!m_fDisabled) 
	    m_usb.Close();
}


//******************************************************************************
//******************************************************************************
// DeviceManager class

DeviceManager::DeviceManager() :
	m_ActiveMode(PDMODE_UNKNOWN),
	m_pCurrentBoard(NULL),
    m_fAbortOperation(false),
	m_fIsOpen(false)
{
}
DeviceManager::~DeviceManager()
{
	ClearDeviceList();
  //  if(libHandle != NULL) FreeLibrary(libHandle);
}

void DeviceManager::ClearDeviceList()
{
	m_pCurrentBoard = NULL;
	while(m_paBoards.GetCount() > 0)
	{
		CDemoBoard* pd = m_paBoards.GetAt(0);
		m_paBoards.RemoveAt(0);
		delete pd;
	}
}

// Clear and rebuild the list of devices availbe to the current mode (boot/demo)
void DeviceManager::Refresh()
{
	CString temp;

	// Scan for USB Devices and place them in the CDemoBoard List
	ClearDeviceList();

	LPCSTR psNoun = "";
	if (PDMODE_BOOT == m_ActiveMode)
		psNoun = "Boot";
	else if (PDMODE_DEMO == m_ActiveMode)
		psNoun = "Demo";

	UINT count = GetDeviceCount(m_ActiveMode);
	for(UINT i = 0; i < count; i++)
	{
		temp.Format("PICDEM FS USB %d (%s)",i, psNoun);
		CDemoBoard *dev = new CDemoBoard(temp,m_ActiveMode,i);
		m_paBoards.Add(dev);
	}
}

UINT DeviceManager::GetDeviceCount(PDMODE mode)
{
	LPSTR psPidVid = "";
	if (PDMODE_BOOT == mode)
		psPidVid = picdemfs_boot;
	if (PDMODE_DEMO == mode)
		psPidVid = picdemfs_demo;

	return theApp.MPUSB.GetDeviceCount(psPidVid);
}

// Fills the given ComboBox with all known devices
void DeviceManager::FillDeviceCombo(CComboBox& combo)
{
	for (int i=0; i<m_paBoards.GetCount(); i++)
    {
        CDemoBoard *Obj = m_paBoards.GetAt(i);
		combo.InsertString(0, Obj->m_sDeviceName);
    }
}

// Selects a device and assigns it to m_pCurrentBoard.
// CDemoBoard must be "opened" by a subsequent call to OpenDevice()
bool DeviceManager::SelectDevice(LPCSTR psDeviceName)
{
	if (m_pCurrentBoard) 
		m_pCurrentBoard->Close();

    Refresh();

    for (int i = 0; i < m_paBoards.GetCount(); i++)
    {
        m_pCurrentBoard = NULL;
        CDemoBoard *pDvc = m_paBoards.GetAt(i);
        if ((pDvc->m_sDeviceName == psDeviceName) && (pDvc->GetMode() == this->m_ActiveMode) )
        {
             m_pCurrentBoard = pDvc;
             break;
        }
    }
    return (NULL != m_pCurrentBoard);
}

// Opens device previously selected by SelectDevice()
bool DeviceManager::OpenDevice()
{
    if (m_pCurrentBoard && !m_fIsOpen) 
        m_fIsOpen = m_pCurrentBoard->Open();

    return m_fIsOpen;
}

// Closes the current device, if any
void DeviceManager::CloseDevice()
{
    if (m_pCurrentBoard && m_fIsOpen) 
	{
        m_fIsOpen = false;
        m_pCurrentBoard->Close();
    }
	else
	{
	    Refresh();
	}
}

// Sends a command to reset the board (processor)
// This will cause the USB connection to reset
bool DeviceManager::ResetBoard()
{
	bool fOK = false;
	if(m_pCurrentBoard)
	{
		USBTXN txn(CMD_RESET, 0);
		fOK = m_pCurrentBoard->DoUsbTransaction(txn);
	}
	return fOK;
}

// Retrieve a string containing the board fw's version, or an error message on failure
CString DeviceManager::ReadVersion()
{
	CString sRet("Demo board not selected.");
	if (m_pCurrentBoard)
	{
		sRet = "(Failed to obtain Version)";
		USBTXN txn(CMD_READ_VERSION, 4);
		txn.AddTxByte(0x02);	// Just "some value" for buf[1] - the f/w expects 2 bytes
		if(m_pCurrentBoard->DoUsbTransaction(txn))
		{
			if(txn.ValidateRxData(4, 2))
				sRet.Format("%d.%d",txn.rx.buf[3],txn.rx.buf[2]);
		}
	}
	return sRet;
}

// Send a command to read FLASH; returns the received data
CByteBuf* DeviceManager::readmem(MEMGRP mg, UINT uAddr, UINT uLen)
{
	CByteBuf* pbb = NULL;
	if(m_pCurrentBoard)
	{
		bool fError = true;
		FWCMD cmd;
		CString sNoun("???");
		switch(mg)
		{
			case MG_PGM:
				cmd = CMD_READ_FLASH;
				sNoun = "FLASH";
				fError = false;
				break;
			case MG_CFG:
				cmd = CMD_READ_CONFIG;
				sNoun = "Config";
				fError = false;
				break;
			case MG_EE:
				cmd = CMD_READ_EEDATA;
				sNoun = "EEPROM";
				fError = false;
				break;
			default:
				ASSERT(0);
				break;
		}

		if(!fError)
		{
			pbb = new CByteBuf();

			int nLoops = 0;
			while(!m_fAbortOperation && !fError && (pbb->GetCount()<(int)uLen))
			{
				DWORD dwReadAddr = uAddr+pbb->GetCount();
				if(!(nLoops%0x40))
				{
					theApp.SetStatusMessage(FmtStr("Read %s mem @ 0x%06X",sNoun, dwReadAddr));
					theApp.ProcessMessages();	// process e.g. click on Abort
				}
				nLoops++;

				// USB packet is 64 bytes; rx'ed data contains our 5 byte hdr plus up to 59 bytes of data
				UINT rxdatalen = uLen-pbb->GetCount();
				if (rxdatalen >= USB_PACKET_DATA_SIZE)
					rxdatalen = USB_PACKET_DATA_SIZE;

				USBTXN txn;
				txn.PrepMemCmdPktHdr(cmd, rxdatalen, dwReadAddr);//(uAddr+pbb->GetCount()));
				txn.rx.count.expected = rxdatalen + USB_PACKET_HDR_SIZE;

				// Tx the 5-byte header
				// Rx a 5-byte header plus data
				if(m_pCurrentBoard->DoUsbTransaction(txn))
				{
					if(txn.ValidateRxData(txn.rx.count.expected, 1))
					{
						pbb->Append(&txn.rx.buf[USB_PACKET_HDR_SIZE], txn.rx.count.actual-USB_PACKET_HDR_SIZE);
					}
					else
					{
						fError = true;
					}
				}
				else
				{
					fError = true;
				}
			}
		}
		if(pbb && (m_fAbortOperation || fError) )
		{
			delete pbb;
			pbb = NULL;
		}
	}
	return pbb;
}

// Erase the indicated memory area
// Note that the demo f/w only supports erasing some memory areas.
bool DeviceManager::EraseMem(MEMGRP mg)
{
	bool fOK = false;
	UINT uBaseAddr=0, uEraseCount=0;
	CString sNoun("???");
	switch(mg)
	{
		case MG_PGM:
			uBaseAddr = USER_FLASH_BASE_ADDR;
			uEraseCount = USER_FLASH_SIZE;
			sNoun = "FLASH";
			break;
		case MG_UID:
			uBaseAddr = PIC_UID_SEGADDR;
			// Though we only have 8 bytes of UID data, erses are performed 
			//  on 64 byte blocks, thus the count is 64.
			// The PIC will ignore our request to erase those extra 56 bytes 
			//  that don't actually exist.
			uEraseCount = ERASE_BLOCK_SIZE;
			sNoun = "UserData";
			break;
		case MG_CFG:
		case MG_DEVID:
		case MG_EE:
			break;
	}
	if(uEraseCount)
	{
		theApp.ShowMessage(FmtStr("Erasing %s...", sNoun));
		if(m_pCurrentBoard)
		{
			UINT uBytesErased = 0;
			UINT uBlockSize = ERASE_BLOCK_SIZE;

			if(0 == (uBaseAddr&uBlockSize) )
			{
				bool fError = false;
				while(!m_fAbortOperation && !fError && (uBytesErased<uEraseCount))
				{
					DWORD dwEraseAddr = uBaseAddr+uBytesErased;
					if(!(dwEraseAddr&0xFF))
					{
						theApp.SetStatusMessage(FmtStr("Erase 0x%06X",dwEraseAddr));
						theApp.ProcessMessages();	// process e.g. click on Abort
					}

					USBTXN txn;
					txn.PrepMemCmdPktHdr(CMD_ERASE_FLASH, 1, dwEraseAddr);
					txn.rx.count.expected = 1;
					DWORD dwAddr = (txn.tx.pkt.raw[4]<<16) | (txn.tx.pkt.raw[3]<<8) | (txn.tx.pkt.raw[2]);
					if (m_pCurrentBoard->DoUsbTransaction(txn))
					{
						if(txn.ValidateRxData(1,1))
							uBytesErased += uBlockSize;
						else
						{
							fError = true;
							theApp.ShowWarning("Bad bootloader response on erase");
						}
					}
					else
					{
						fError = true;
						theApp.ShowWarning("Failed to send erase command");
					}
				}
				fOK = (! m_fAbortOperation && !fError && (uBytesErased==uEraseCount) );
			}
			else
			{
				// The boot firmware operates on 64-byte chunks
				theApp.ShowWarning("Flash-erase address not on 64 byte boundary");
			}
		}
	}
	return fOK;
}

// Helper function that performs the real work of all memory writes
bool DeviceManager::writemem(MEMGRP mg, UINT uRelAddr, CByteBuf& data)
{
	bool fOK = false;
	bool fError = true;

	DWORD dwSegAddr = 0;
	UINT uWriteIdx = 0;
	FWCMD cmdWrite, cmdRead;
	CString sNoun("???");
	switch(mg)
	{
		case MG_PGM: 
			// For program memory, we skip the first 0x800 bytes.
			// Those are the protected boot block.
			uWriteIdx = USER_FLASH_BASE_ADDR;
			cmdWrite = CMD_WRITE_FLASH;
			cmdRead = CMD_READ_FLASH;
			sNoun = "FLASH";
			fError = false;
			break;
		case MG_EE:
			cmdWrite = CMD_WRITE_EEDATA;
			cmdRead = CMD_READ_EEDATA;
			sNoun = "EEPROM";
			fError = false;
			break;
		case MG_UID:
			dwSegAddr = PIC_UID_SEGADDR;
			cmdWrite = CMD_WRITE_FLASH;
			cmdRead = CMD_READ_FLASH;
			sNoun = "UserID";
			fError = false;
			break;
		case MG_CFG:
			dwSegAddr = PIC_CFG_SEGADDR;
			cmdWrite = CMD_WRITE_CONFIG;
			cmdRead = CMD_READ_CONFIG;
			sNoun = "Config";
			fError = false;
			break;
		default:
			break;
	}

	if (m_pCurrentBoard && !fError)
	{
		theApp.ShowMessage(FmtStr("Programming %s...", sNoun));
		LPCBYTE pbData = data;
		UINT uWriteCount = data.GetCount();
		while((uWriteIdx<uWriteCount) && !fError && !m_fAbortOperation)
		{
			DWORD dwPgmAddr = uRelAddr+uWriteIdx;
			if(!(dwPgmAddr & 0x0FF))
			{
				theApp.SetStatusMessage(FmtStr("Write 0x%06X",dwPgmAddr));
				theApp.ProcessMessages();	// process e.g. click on Abort
			}

			USBTXN txnWrite;
			txnWrite.PrepMemCmdPktHdr(cmdWrite, PGM_BLOCK_SIZE, (dwSegAddr+dwPgmAddr));
			txnWrite.rx.count.expected = 1;

			int nDataCount = uWriteCount - uWriteIdx;
			if(nDataCount > PGM_BLOCK_SIZE)
				nDataCount = PGM_BLOCK_SIZE;
			LPCBYTE pbSrc = pbData+dwPgmAddr;
			memcpy(txnWrite.tx.pkt.data, pbSrc, nDataCount);
			txnWrite.tx.count += nDataCount;

			if (m_pCurrentBoard->DoUsbTransaction(txnWrite))
			{
				if(txnWrite.ValidateRxData(1, 1))
				{
					// Read back the address block we just wrote & validate it
					USBTXN txnRead;
					txnRead.PrepMemCmdPktHdr(cmdRead, nDataCount, (dwSegAddr+dwPgmAddr));
					txnRead.rx.count.expected = nDataCount + USB_PACKET_HDR_SIZE;
					if(m_pCurrentBoard->DoUsbTransaction(txnRead))
					{
						if(txnRead.ValidateRxData(txnRead.rx.count.expected, 1))
						{
							USBPACKET* pPkt = (USBPACKET*)txnRead.rx.buf;
							int chkIdx;
							for(chkIdx=0; chkIdx<nDataCount; chkIdx++)
							{
								if(pPkt->data[chkIdx] != txnWrite.tx.pkt.data[chkIdx])
								{
									fError = true;
									theApp.ShowWarning(FmtStr("Verify failed at 0x%06lX", (dwSegAddr+dwPgmAddr+chkIdx)));
									break;
								}
							}
							if(!fError)
								uWriteIdx += nDataCount;
						}
						else
						{
							fError = true;
							theApp.ShowWarning("Bad bootloader response on read");
						}
					}
					else
					{
						fError = true;
						theApp.ShowWarning("Failed to send read command");
					}
				}
				else
				{
					fError = true;
					theApp.ShowWarning("Bad bootloader response on write");
				}
			}
			else
			{
				fError = true;
				theApp.ShowWarning("Failed to send write command");
			}
		}
	}

	fOK = (!fError && !m_fAbortOperation);
	if(!fOK)
		theApp.ShowWarning(FmtStr("Failed to program %s", sNoun));
	return fOK;
}



/*** DEMO MODE FUNCTIONALITY ***/

// Sends the command to turn the given LED on/off
bool DeviceManager::UpdateLED(UINT led, int nOn)
{
	bool fOK = false;
	if(m_pCurrentBoard) 
	{
		USBTXN txn(CMD_UPDATE_LED, 1);
		txn.AddTxByte(led);
		txn.AddTxByte(nOn?1:0);
		if (m_pCurrentBoard->DoUsbTransaction(txn))
			fOK = txn.ValidateRxData(1, 1);
	}
	return fOK;
}

// Sets the board to perform real-time temperature display
void DeviceManager::SetTempRealMode()
{
	if (m_pCurrentBoard)
	{
		USBTXN txn(CMD_SET_TEMP_REAL, 1);
		if ( m_pCurrentBoard->DoUsbTransaction(txn))
		{
			ASSERT(txn.ValidateRxData(1,1));
		}
	}
}

// Retrieves current temperature value
bool DeviceManager::ReadTemperature(WORD& wTemperature)
{
	bool fOK = false;
	if (m_pCurrentBoard)
	{
		USBTXN txn(CMD_RD_TEMP, 3);
		if(m_pCurrentBoard->DoUsbTransaction(txn))
		{
			if(txn.ValidateRxData(3, 1))
			{
				wTemperature = MAKEWORD(txn.rx.buf[1], txn.rx.buf[2]);
				fOK = true;
			}
		}
	}
	return fOK;
}

// Sets the board to use data-logging temperature
void DeviceManager::SetTempLogging()
{
	if (m_pCurrentBoard)
	{
		USBTXN txn(CMD_SET_TEMP_LOGGING, 1);
		if(m_pCurrentBoard->DoUsbTransaction(txn))
		{
			ASSERT(txn.ValidateRxData(1,1));
		}
	}
}

// Retrieves any/all available temperature data from the board's temperature log
bool DeviceManager::ReadTempLogging(CByteBuf& bbData)
{
	bool fOK = false;
	bbData.Empty();
	if (m_pCurrentBoard) 
	{
		// CMD_RD_TEMP_LOGGING replies with one byte of command (==CMD_RD_TEMP_LOGGING) 
		//   plus 'n' WORDs of temperature data.
		BYTE bMaxData = ((USB_PACKET_SIZE-1)/2)*2;	// =62
		USBTXN txn(CMD_RD_TEMP_LOGGING, bMaxData);
		if(m_pCurrentBoard->DoUsbTransaction(txn))
		{
			if(CMD_RD_TEMP_LOGGING == txn.rx.buf[0])
			{
				bbData.SetData(&txn.rx.buf[2], txn.rx.buf[1]);
				fOK = true;
			}
		}
	}
	return fOK;
}

// Retrieves the board's potentiometer setting
bool DeviceManager::ReadPot(WORD& wPotValue)
{
	bool fOK = false;
	if(m_pCurrentBoard)
	{
		USBTXN txn(CMD_RD_POT, 3);
		if(m_pCurrentBoard->DoUsbTransaction(txn))
		{
			if( txn.ValidateRxData(3, 1) )
			{
				wPotValue = MAKEWORD(txn.rx.buf[1], txn.rx.buf[2]);
				fOK = true;
			}
		}
	}
	return fOK;
}


//******************************************************************************
//******************************************************************************
// USBPort class

HANDLE USBPort::m_hBulkOut = INVALID_HANDLE_VALUE;
HANDLE USBPort::m_hBulkIn = INVALID_HANDLE_VALUE;

USBPort::USBPort(int assignedIndex):
	m_nAssignedIndex(assignedIndex)
{
    m_hBulkOut = m_hBulkIn = INVALID_HANDLE_VALUE;
}

// Destructor for USB class. Closes the USB Ports if they are open.
USBPort::~USBPort()
{
	Close();
}

// Opens read/write handles to the USB device for the given mode (boot/demo)
bool USBPort::Open(PDMODE mode)
{
	Close();

	if (PDMODE_BOOT == mode)
	{
		m_hBulkOut = theApp.MPUSB.Open(m_nAssignedIndex,picdemfs_boot,bulk_out,MP_WRITE,0);
		m_hBulkIn = theApp.MPUSB.Open(m_nAssignedIndex,picdemfs_boot,bulk_in,MP_READ,0);
	}
	else
	{
		m_hBulkOut = theApp.MPUSB.Open(m_nAssignedIndex,picdemfs_demo,bulk_out,MP_WRITE,0);
		m_hBulkIn = theApp.MPUSB.Open(m_nAssignedIndex,picdemfs_demo,bulk_in,MP_READ,0);

	}
	return ((m_hBulkOut != INVALID_HANDLE_VALUE) && (m_hBulkIn != INVALID_HANDLE_VALUE));
}

// Closes the USB CDemoBoard (read/write handles)
void USBPort::Close()
{
    if (m_hBulkOut != INVALID_HANDLE_VALUE) 
		theApp.MPUSB.Close(m_hBulkOut);
    if (m_hBulkIn != INVALID_HANDLE_VALUE) 
		theApp.MPUSB.Close(m_hBulkIn);
    m_hBulkOut = m_hBulkIn = INVALID_HANDLE_VALUE;
}

// Perform a "transaction" with the board:
// Send the desired data via the USB port then, if requested, read data back out of the port.
bool USBPort::DoUsbTransaction(USBTXN& txn)
{
	bool fOK = false;

    if(m_hBulkOut != INVALID_HANDLE_VALUE && m_hBulkIn != INVALID_HANDLE_VALUE)
    {
	    DWORD dwSent=0;
		if(theApp.MPUSB.Write(m_hBulkOut,(PVOID)txn.tx.pkt.raw, txn.tx.count, &dwSent, txn.tx.timeout))
        {
			ASSERT(dwSent == (DWORD)txn.tx.count);
			if(txn.rx.count.expected > 0)
			{
				DWORD dwRxed = 0;
				if(theApp.MPUSB.Read(m_hBulkIn, txn.rx.buf, txn.rx.count.expected, &dwRxed, txn.rx.timeout))
				{
					txn.rx.count.actual = (BYTE)dwRxed;
					// ASSERT(txn.rx.count.expected == txn.rx.count.actual); NO - some xfers accept less than requested
					fOK = true;
				}
				else
				{
					if(LogUsbError("USB Read Failed") == ERROR_INVALID_HANDLE)
					{
						if (m_hBulkOut != INVALID_HANDLE_VALUE)
							theApp.MPUSB.Close(m_hBulkOut);
						if (m_hBulkIn != INVALID_HANDLE_VALUE)
							theApp.MPUSB.Close(m_hBulkIn);
						m_hBulkOut = m_hBulkIn = INVALID_HANDLE_VALUE;
					}
				}
			}
			else
			{
				fOK = true;
			}
        }
        else
        {
            if(LogUsbError("USB Write Failed") == ERROR_INVALID_HANDLE)
            {
              if (m_hBulkOut != INVALID_HANDLE_VALUE)
                theApp.MPUSB.Close(m_hBulkOut);
              if (m_hBulkIn != INVALID_HANDLE_VALUE)
                theApp.MPUSB.Close(m_hBulkIn);
              m_hBulkOut = m_hBulkIn = INVALID_HANDLE_VALUE;
            }
        }
    }

    return fOK;
}
