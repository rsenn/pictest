#pragma once

// CTabDlg dialog

class CTabDlg : public CDialog
{
	DECLARE_DYNAMIC(CTabDlg)

public:
	CTabDlg(UINT nIDTemplate);
	virtual ~CTabDlg();

	BOOL CreateTab(CWnd* pParent, int x, int y, int cx, int cy);

	virtual void Activate(bool fActivate)=0;	// Called when user switches tabs
	virtual void SetAutoConnect(bool fAuto)	{m_fAutoConnect=fAuto;}

// Dialog Data

protected:
	UINT m_nIDTemplate;
	bool m_fAutoConnect;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
