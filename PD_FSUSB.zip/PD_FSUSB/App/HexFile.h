#pragma once
// HexFile.h
// Implements the required functionalty to load and save Intel HEX files into application buffers.

#include "defs.h"
#include "ByteBuf.h"

// The record types in an Intel HEX file
typedef enum
{
	// The assigned value is the actual rectype value
	HRT_DATA=0x00,			// Data record
	HRT_EOF=0x01,			// End Of File record
	HRT_EXTSEG=0x02,		// Extended Segment Address Record
	HRT_STARTSEG=0x03,		// Start Segment Address Record
	HRT_EXTLINADDR=0x04,	// Extended Linear Address Record
	HRT_STARTLINADDR=0x05,	// Start Linear Address Record
} HEXRECTYPE;

struct HEXMEMBLOCK
{
	WORD m_wBaseAddr;
	CByteBuf m_data;
	HEXMEMBLOCK() : m_wBaseAddr(-1) {}
};
struct MEMBLOCKENUM
{
	HEXMEMBLOCK* pmb;
	int nIdx;
	MEMBLOCKENUM() : pmb(NULL), nIdx(-1) {}
};
class CHexMemGroup
{
public:
	CHexMemGroup(MEMGRP mg) : m_mg(mg)		{}
	~CHexMemGroup()		{Empty();}

	void Empty()
	{
		for(int i=0; i<m_blocks.GetCount(); i++)
			delete m_blocks[i];
		m_blocks.RemoveAll();
	}
	bool IsEmpty()		{return (0==GetBlockCount());}
	int GetBlockCount()	{return (int)m_blocks.GetCount();}
	HEXMEMBLOCK* GetBlock(int b)
	{
		HEXMEMBLOCK* pmb = NULL;
		if((b>=0)&&(b<GetBlockCount()))
			pmb = m_blocks.GetAt(b);
		ASSERT(pmb);
		return pmb;
	}
	bool EnumBlocks(MEMBLOCKENUM& mbe)
	{
		mbe.pmb = NULL;
		if((mbe.nIdx+1)<GetBlockCount())
		{
			mbe.nIdx++;
			mbe.pmb = GetBlock(mbe.nIdx);
		}
		return (NULL != mbe.pmb);
	}
	bool Add(WORD wAddAddr, CByteBuf& data)
	{
		bool fError = false;
		HEXMEMBLOCK* pmb = NULL;
		for(int b=0; (!fError && (b<m_blocks.GetCount()) ); b++)
		{
			pmb = m_blocks.GetAt(b);
			WORD wNext = pmb->m_wBaseAddr + pmb->m_data.GetCount();
			if(wNext == wAddAddr)
				break;
			else if (wAddAddr < wNext)
			{
				fError = true;
				theApp.ShowWarning("Invalid address sequence");
			}
			else
				pmb = NULL;
		}

		if(!fError)
		{
			if(!pmb)
			{
				pmb = new HEXMEMBLOCK;
				pmb->m_wBaseAddr = wAddAddr;
				m_blocks.Add(pmb);
			}
			pmb->m_data += data;
		}
		return !fError;
	}

	WORD GetGroupSegmentAddr()	{return GetGroupSegmentAddr(m_mg);}
	static WORD GetGroupSegmentAddr(MEMGRP mg)
	{
		WORD wSegAddr = -1;
		switch(mg)
		{
			case MG_PGM:
			case MG_UID:
			case MG_CFG:
			case MG_DEVID:
			case MG_EE:
				wSegAddr = mg;
				break;
		}
		return wSegAddr;
	}

	WORD GetGroupOffsetBaseAddr()	{return GetGroupOffsetBaseAddr(m_mg);}
	static WORD GetGroupOffsetBaseAddr(MEMGRP mg)
	{
		WORD wBaseAddr = -1;
		switch(mg)
		{
			case MG_PGM:	wBaseAddr=(PIC_PGM_SEGADDR&0xFFFF);	break;	// 0x(0000)0000
			case MG_UID:	wBaseAddr=(PIC_UID_SEGADDR&0xFFFF);	break;	// 0x(0020)0000
			case MG_CFG:	wBaseAddr=(PIC_CFG_SEGADDR&0xFFFF);	break;	// 0x(0030)0000
			case MG_DEVID:	wBaseAddr=(PIC_REGADDR_DEVID1&0xFFFF);	break;	// 0x(003F)FFFE
			case MG_EE:		wBaseAddr=(PIC_EE_SEGADDR&0xFFFF);	break;	// 0x(00F0)0000
		}
		return wBaseAddr;
	}

protected:
	MEMGRP m_mg;
	CTypedPtrArray<CPtrArray, HEXMEMBLOCK*> m_blocks;
};
class CHexFile
{
public:
	CHexFile();
	~CHexFile();

	bool ImportP18HEXFile(LPCSTR psFileName);
	bool ExportP18HEXFile(LPCSTR psFileName);

	void Empty();
	bool IsEmpty();

	bool IsValid()		{return m_fValid;}
	void ForceValid()	{m_fValid = true;}

	void SetGroupData(MEMGRP mg, CByteBuf& data);
	void AddGroupData(MEMGRP mg, WORD wRelAddr, CByteBuf& data);

	MEMGRP GetGroupID(WORD wAddress);
	CHexMemGroup* GetGroup(MEMGRP mg);
	bool GetGroup(MEMGRP mg, CHexMemGroup*& pmg)
	{
		pmg = GetGroup(mg);
		return (NULL != pmg);
	}
	CString GetGroupListing(MEMGRP mg);

protected:
	bool m_fValid;
	CHexMemGroup m_mgPgm, m_mgEE, m_mgUID, m_mgCfg, m_mgDevID;

	DWORD GetGroupSegmentAddr(MEMGRP mg);
};
