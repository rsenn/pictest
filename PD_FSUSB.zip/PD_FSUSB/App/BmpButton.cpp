// BmpButton.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "BmpButton.h"
#include "BmpCtrl.h"


// CBmpButton

IMPLEMENT_DYNAMIC(CBmpButton, CButton)

CBmpButton::CBmpButton(UINT uIdb)
{
	m_imgEnbl.LoadFromResource( AfxGetInstanceHandle(), uIdb);

	COLORREF crSwap[] = {RGB(0xff,0xff,0xff), RGB(0,0xff,0)};
	int nSwap = sizeof(crSwap)/sizeof(crSwap[0]);
	COLORREF crTarget = RGB(0,0,0);

	// Create "disabled" version of the image by changing white and 
	//    green px to black, then dropping out all but black, 
	//    then replacing black with a faded color.
	m_imgDisabled.LoadFromResource( AfxGetInstanceHandle(), uIdb);
	m_imgDisabled.ConvertColors(crTarget, crSwap, nSwap, COLOR_BTNSHADOW);

	// Create a drop shadow for the disabled image
	m_imgDisblShadow.LoadFromResource( AfxGetInstanceHandle(), uIdb);
	m_imgDisblShadow.ConvertColors(crTarget, crSwap, nSwap, COLOR_BTNHILIGHT);
}

CBmpButton::~CBmpButton()
{
}


BEGIN_MESSAGE_MAP(CBmpButton, CButton)
END_MESSAGE_MAP()


// CBmpButton message handlers

void CBmpButton::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
	BOOL fOK = FALSE;
	if(lpDIS)
	{
		if(GetWindowLong(m_hWnd, GWL_ID) == lpDIS->CtlID)
		{
			//***************************
			// PREP
			//***************************
			CDC* pdc = CDC::FromHandle(lpDIS->hDC);
			BOOL fEnabled = IsWindowEnabled();
			// Get the size of the client rectangle.
			CRect rc;
			GetClientRect(&rc);
			// Create a compatible DC.
			CDC dcMem;
			dcMem.CreateCompatibleDC(pdc);
			dcMem.SelectObject(pdc->GetCurrentFont());
			// Create a bitmap big enough for our client rectangle.
			CBitmap bmpMem;
			bmpMem.CreateCompatibleBitmap(pdc, rc.Width(), rc.Height());
			// Select the bitmap into the off-screen DC.
			CBitmap* pbmOld = dcMem.SelectObject(&bmpMem);

			// The system colors used in drawing the button
			COLORREF rgbBkgnd = GetSysColor(COLOR_BTNFACE);
			COLORREF rgbHilite = GetSysColor(COLOR_BTNHILIGHT);
			COLORREF rgbShadow = GetSysColor(COLOR_BTNSHADOW);
			COLORREF rgbDkShadow = GetSysColor(COLOR_3DDKSHADOW);
			COLORREF rgbText = GetSysColor(COLOR_BTNTEXT);

			//***************************
			// FRAME
			// Draw the std-looking button frame
			//***************************
			CRect rcFrame(lpDIS->rcItem);

			dcMem.FillSolidRect(&rcFrame, rgbBkgnd);

			BOOL fDown = (ODS_SELECTED == (lpDIS->itemState&ODS_SELECTED));
			BOOL fFocused = (ODS_FOCUS == (lpDIS->itemState&ODS_FOCUS));

			// This is the rect for the inner contents (bmp and text)
			CRect rcContent(rcFrame);
			rcContent.DeflateRect(4, 4);

			// The button always has a dark line at the bottom & right
			if(!fDown)
			{
				dcMem.Draw3dRect(&rcFrame, rgbBkgnd, rgbDkShadow);
				rcFrame.bottom--; rcFrame.right--;
			}

			if(fFocused)
			{
				dcMem.Draw3dRect(&rcFrame, RGB(0,0,0), RGB(0,0,0));
				rcFrame.DeflateRect(1, 1);
			}

			dcMem.Draw3dRect(&rcFrame, fDown?rgbShadow:rgbHilite, rgbShadow);

			if(lpDIS->itemState & ODS_FOCUS)
				dcMem.DrawFocusRect(&rcContent);
			rcContent.DeflateRect(2, 2);

			COLORREF crOldBk = dcMem.SetBkColor(rgbBkgnd);
			COLORREF crOldText = dcMem.SetTextColor(rgbText);
			dcMem.SetBkMode(TRANSPARENT);

			//***************************
			// CONTENT
			// Draw button's image & text in rcContent
			//***************************
			int y = (rcContent.Height()-m_imgEnbl.GetHeight())/2;
			rcContent.left += 6;
			if(fDown)
			{
				y++;
				rcContent.left ++;
			}

			int xBmp = rcContent.left;
			int yBmp = rcContent.top+y;
			if(fEnabled)
			{
				m_imgEnbl.TransparentBlt(dcMem, xBmp, yBmp, m_imgEnbl.GetWidth(), m_imgEnbl.GetHeight(), DEFAULT_TRANSP_COLOR );
			}
			else
			{
				m_imgDisblShadow.TransparentBlt(dcMem, xBmp+1, yBmp+1, m_imgDisblShadow.GetWidth(), m_imgDisblShadow.GetHeight(), DEFAULT_TRANSP_COLOR );
				m_imgDisabled.TransparentBlt(dcMem, xBmp, yBmp, m_imgDisabled.GetWidth(), m_imgDisabled.GetHeight(), DEFAULT_TRANSP_COLOR );
			}

			rcContent.left += (m_imgEnbl.GetWidth()+8);
			CString sText;
			GetWindowText(sText);
			CSize sizeTxt = dcMem.GetTextExtent(sText);
			y = (rcContent.Height()-sizeTxt.cy)/2;
			if(fDown)
				y++;
			rcContent.top += y;

			if(!fEnabled)
			{
				rcContent.OffsetRect(1,1);
				dcMem.SetTextColor(GetSysColor(COLOR_BTNHILIGHT));
				dcMem.DrawText(sText, rcContent, DT_LEFT);
				rcContent.OffsetRect(-1,-1);
				dcMem.SetTextColor(GetSysColor(COLOR_BTNSHADOW));
			}
			dcMem.DrawText(sText, rcContent, DT_LEFT);

			// Finally, blt the offscreen-composed image to the screen DC.
			pdc->BitBlt(rc.left, rc.top, rc.Width(), rc.Height(), &dcMem, 0, 0, SRCCOPY);

			//***************************
			// CLEANUP
			//***************************
			dcMem.SetBkColor(crOldBk);
			dcMem.SetTextColor(crOldText);
			dcMem.SelectObject(pbmOld);
		}
	}
}

void CBmpButton::PreSubclassWindow()
{
	// Force owner-draw even if not set in the RC
	DWORD dw = GetStyle();
	dw |= BS_OWNERDRAW;
	::SetWindowLong(m_hWnd, GWL_STYLE, dw);
	dw = GetStyle();

	CButton::PreSubclassWindow();
}

void CBmpButton::OnEnable(BOOL bEnable)
{
	CButton::OnEnable(bEnable);

	Invalidate();
}
