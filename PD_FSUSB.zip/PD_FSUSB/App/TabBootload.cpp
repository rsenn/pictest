// TabBootload.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "TabBootload.h"

#define SAVE_CONTEXT    true
#define RESTORE_CONTEXT false

static CString IntToHex(int val, int nDigits)
{
	CString s;
	char szDigit[4];
	while(nDigits-- > 0)
	{
		wsprintf(szDigit, "%02X", val&0xF);
		val >>= 4;
		s += szDigit;
	}
	return s;
}

// CTabBootload dialog

IMPLEMENT_DYNAMIC(CTabBootload, CTabDlg)

CTabBootload::CTabBootload() :
	m_logo(IDB_LOGO),
	m_btnLoad(IDB_BTN_LOAD),
	m_btnSave(IDB_BTN_SAVE),
	m_btnProgram(IDB_BTN_PROGRAM),
	m_btnExecute(IDB_BTN_EXECUTE),
	m_btnRead(IDB_BTN_READ),
	m_btnErase(IDB_BTN_ERASE),
	m_btnAbort(IDB_BTN_ABORT),
	m_fBusy(false),
	CTabDlg(CTabBootload::IDD)
{

}

CTabBootload::~CTabBootload()
{
}

void CTabBootload::Activate(bool fActivate)
{
	ShowWindow(fActivate?SW_SHOW:SW_HIDE);
	if(fActivate)
	{
		theApp.m_DeviceMgr.SetActiveMode(PDMODE_BOOT);
		OnCbnDropdownBootCombo();	// Refresh device list, re-populate combo
		if(m_fAutoConnect)
		{
			if(m_comboChannel.GetCount()>0)
				m_comboChannel.SetCurSel(0);
			OnCbnSelchangeBootCombo();
		}
		theApp.SetStatusReady();
	}
	else
	{
		m_comboChannel.ResetContent();
	}
	UpdateControls();
}

void CTabBootload::SetAutoConnect(bool fAuto)
{
	CTabDlg::SetAutoConnect(fAuto);	// Call base 1st to update m_fAutoConnect
}


/******************************************************************************
 * Function:		TfrmFullSpeedUSBDemoTool::CheckConfiguration(AnsiString& Config)
 *
 * PreCondition:	None
 *
 * Input:			Config - Contains the Config Memory buffer content loaded
 *						from HEX file.
 * Output:			None
 *
 * Side Effects:	None
 *
 * Overview:		The content of the variable Config is verified to check if
 *						all the configuration data required to use USB is available
 *						or not. Based on user input for a Message Box, it can
 *						set the variable Config to a different set of values
 *						than those loaded from HEX file.
 *
 * Note:				None
 *****************************************************************************/

typedef struct _CFGVAL
{
	DWORD dwAddr;	// Configuration Address
	BYTE bDflt;		// Silicon Default Values
	BYTE bFile;		// Value from the Hex file (if set; otherwise == bDflt)
}CFGVAL;

void CTabBootload::CheckConfiguration()
{
	// NOTES:
	// 1. There are configuration registers in the addresses 300000 thru 30000D
	// The config line will be a single line with address and up to 14 bytes of data.

	// If the HEX file loaded may be having only a partial list of
	// initializations, then if any initialization is different from
	// default and missing in the HEX file, show ERROR.

	// If the HEX file has any init value different from what is expected, show an error
	// See Table 25-1 in PIC18F4550 docs (DS39623) for the Config registers & values
	CFGVAL ConfigVals[] = 
	{
		// Addr	   Dflt  File
		{PIC_REGADDR_CONFIG1L, 0x24, 0x24},	// USB Clock Selection, CPU Sys Clock Select, OSC Select
		{PIC_REGADDR_CONFIG1H, 0x0E, 0x0E},	// Oscillator
		{PIC_REGADDR_CONFIG2L, 0x3F, 0x3F},	// USB Voltage Regulator
		{PIC_REGADDR_CONFIG2H, 0x1E, 0x1E},	// Watchdog Timer
		{PIC_REGADDR_CONFIG3L, 0x00, 0x00},	// (not checked)
		{PIC_REGADDR_CONFIG3H, 0x81, 0x81},	// Port B A/D
		{PIC_REGADDR_CONFIG4L, 0x81, 0x81},	// Low Voltage Programming
		{PIC_REGADDR_CONFIG4H, 0x00, 0x00},	// (not checked)
		{PIC_REGADDR_CONFIG5L, 0x0F, 0x0F},	// (not checked)
		{PIC_REGADDR_CONFIG5H, 0xC0, 0xC0},	// (not checked)
		{PIC_REGADDR_CONFIG6L, 0x0F, 0x0F},	// (not checked)
		{PIC_REGADDR_CONFIG6H, 0xA0, 0xA0},	// Boot Block Protect
		{PIC_REGADDR_CONFIG7L, 0x0F, 0x0F},	// (not checked)
		{PIC_REGADDR_CONFIG7H, 0x40, 0x40},	// (not checked)
		{PIC_REGADDR_DEVID1,   0x00, 0x00},	// (not checked)
		{PIC_REGADDR_DEVID2,   0x0B, 0x0B},	// (not checked)
	};
	int nConfigVals = sizeof(ConfigVals)/sizeof(ConfigVals[0]);

	int idx;

	// Even though they were set above, ensure Hex values are defaults
	for(idx=0; idx<nConfigVals; idx++)
		ConfigVals[idx].bFile = ConfigVals[idx].bDflt;


	// Search the Hexfile for config data
	// If found, replace the CFGVAL.bFile value in ConfigVals with the value from the Hexfile
	bool fConfigDataIsDefault = true;
	CHexMemGroup* pCfgGrp = m_hexfile.GetGroup(MG_CFG);
	if(pCfgGrp)
	{
		WORD wSeg = pCfgGrp->GetGroupSegmentAddr();
		MEMBLOCKENUM mbe;
		while(pCfgGrp->EnumBlocks(mbe))
		{
			for(int b=0; b<mbe.pmb->m_data.GetCount(); b++)
			{
				BYTE fileval = mbe.pmb->m_data[b];
				WORD wAddrLo = mbe.pmb->m_wBaseAddr + b;
				DWORD dwAddr = MAKELONG(wAddrLo, wSeg);

				for(int v=0; v<nConfigVals; v++)
				{
					CFGVAL& cfgval = ConfigVals[v];
					if(cfgval.dwAddr == dwAddr)
					{
						if(cfgval.bFile != fileval)
						{
							// This address's file-value is non-default
							cfgval.bFile = fileval;
							fConfigDataIsDefault = false;
						}
					}
				}
			}
		}
	}

	if (!fConfigDataIsDefault)
	{
		// The Hexfile contained config data: Validate the settings.
		bool fConfigError = false;
		for (int idx=0; idx<nConfigVals; idx++)
		{
			CFGVAL& cfgval = ConfigVals[idx];
			switch(cfgval.dwAddr)
			{
				case PIC_REGADDR_CONFIG1L:
					// 1. USB Clock Selection = clk_src__from_96MHz_PLL/2
					if ((cfgval.bFile & 0x20) != 0x20)
					{
						fConfigError = true;
						theApp.ShowWarning("USB Clock Selection is not [ clk_src__from_96MHz_PLL/2] ");
					}
					// 2. CPU Sys Clock Select = no divide (=/2 in PLL mode)
					if ((cfgval.bFile & 0x18) != 0x00)
					{
						fConfigError = true;
						theApp.ShowWarning("CPU Sys Clock Select is not [ no divide (=/2 in PLL mode) ] ");
					}
					// 3. OSC Select  = div by 5 {20 MHz input}
					if ((cfgval.bFile & 0x07) != 0x04)
					{
							fConfigError = true;
							theApp.ShowWarning("OSC Select  is not [ div by 5 {20 MHz input} ]");
					}
					//bSiliconDefaultConfigValues[Index] &= (~0x18);
					//bSiliconDefaultConfigValues[Index] = 0x24;
					break;
				case PIC_REGADDR_CONFIG1H:
					// 1. Oscillator = HS: HS+PLL, USB-HS
					if ((cfgval.bFile & 0x0F) != 0x0E)
					{
						fConfigError = true;
						theApp.ShowWarning("Oscillator is not [ HS: HS+PLL, USB-HS ]");
					}
					//bSiliconDefaultConfigValues[Index] = 0x0E;
					break;
				case PIC_REGADDR_CONFIG2L:
					// 1. USB Voltage Regulator  =  Enabled
					if ((cfgval.bFile & 0x20) != 0x20)
					{
						fConfigError = true;
						theApp.ShowWarning("USB Voltage Regulator  is not [ Enabled ]");
					}
					//bSiliconDefaultConfigValues[Index] = 0x3F;
					break;
				case PIC_REGADDR_CONFIG2H:
					// 1. Watchdog Timer  = Disabled
					if ((cfgval.bFile & 0x01) == 0x01)
					{
						fConfigError = true;
						theApp.ShowWarning("Watchdog Timer is not [ Disabled ]");
					}
					//bSiliconDefaultConfigValues[Index] &= 0xFE;
					break;
				case PIC_REGADDR_CONFIG3H:
					// 1. Port B A/D = configured as Digital I/O
					if ((cfgval.bFile & 0x02) == 0x02)
					{
						fConfigError = true;
						theApp.ShowWarning(" Port B A/D is not [ configured as Digital I/O ]");
					}
					//bSiliconDefaultConfigValues[Index] &= 0xFD;
					break;
				case PIC_REGADDR_CONFIG4L:
					// 1. Low Voltage Programming = Disabled
					if ((cfgval.bFile & 0x04) == 0x04)
					{
						fConfigError = true;
						theApp.ShowWarning(" Low Voltage Programming is not [ Disabled ]");
					}
					//bSiliconDefaultConfigValues[Index] &= 0xFB;
					break;
				case PIC_REGADDR_CONFIG6H:
					// Table Write Protect for Boot Block Enable
					if (cfgval.bFile != 0xA0)
					{
						fConfigError = true;
						theApp.ShowWarning(" Table Write Protect Boot is not [ Enabled ]");
					}
					cfgval.bFile &= 0xA0;	// Clear WRTB (Force protection)
					break;
			}
		}

		if (fConfigError)
		{
			LPCSTR psMsg = "Configuration data contained in this hex file is\r\n"
							"different from the board's default setting.\r\n\n"
							"Using a different setting could cause the bootload\r\n"
							"interface to stop functioning.\r\n\n"
							"Click:\r\n"
							"Yes - To use the setting contained in the hex file.\r\n"
							"No - To use the board's default setting.\r\n"
							"Cancel - To use the board's current setting.\r\n";

			int mbCode = ::MessageBox(NULL, psMsg, "Configuration Data", MB_YESNOCANCEL|MB_TASKMODAL|MB_ICONWARNING|MB_DEFBUTTON3);
			if (mbCode == IDNO)
			{
				// Reset the Config's content to default values.
				ASSERT(0);
	/*
				sConfig = "\r\n300000 ";
				for (Index = 0; Index < 0x10-2; Index++)
				{
					sConfig += IntToHex(bSiliconDefaultConfigValues[Index],2) + " ";
				}
	//			Config = Config + "\r\n3FFFFE " +IntToHex(bSiliconDefaultConfigValues[Index++],2) + " ";
	//			Config = Config + "\r\n3FFFFF "+IntToHex(bSiliconDefaultConfigValues[Index],2) + " ";
				theApp.ShowWarning("CONFIGURATION MEMORY Changed to : \r\n"+sConfig+"\r\n");
	*/
			}
			else if(mbCode == IDCANCEL)
			{
	//			sConfig.Empty();
				ASSERT(0);
			}
		}
	}
}

void CTabBootload::UpdateControls()
{
	bool fHaveDevice = theApp.m_DeviceMgr.IsDeviceSelected();
	bool fHaveHexdata = (!m_hexfile.IsEmpty() && m_hexfile.IsValid());

	m_btnProgram.EnableWindow(!m_fBusy && fHaveDevice && fHaveHexdata);
	m_btnSave.EnableWindow(!m_fBusy && fHaveHexdata);
	m_btnAbort.EnableWindow(m_fBusy);
	m_btnRead.EnableWindow(!m_fBusy && fHaveDevice);
	m_btnExecute.EnableWindow(!m_fBusy && fHaveDevice);
	m_btnErase.EnableWindow(!m_fBusy && fHaveDevice);
	m_btnLoad.EnableWindow(!m_fBusy);

	theApp.ProcessMessages();	// Allow UI to update
}

static void LogSection(LPCSTR psTitle, LPCSTR psData)
{
	theApp.Logln(psTitle);
	theApp.Logln(psData);
	if(*psData)
		theApp.Logln();
}
void CTabBootload::ShowHexContent()
{
	theApp.Logln("Addr:  00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F");
	theApp.Logln();
	LogSection("PROGRAM MEMORY:", m_hexfile.GetGroupListing(MG_PGM));
	LogSection("EEPROM MEMORY:", m_hexfile.GetGroupListing(MG_EE));
	LogSection("USER ID MEMORY:", m_hexfile.GetGroupListing(MG_UID));
	LogSection("CONFIGURATION MEMORY:", m_hexfile.GetGroupListing(MG_CFG));
	LogSection("DEVICE ID MEMORY:", m_hexfile.GetGroupListing(MG_DEVID));
}

// Updates the control's state from enabled to disabled,
//   or from disabled to enabled based on the value of the argument update.
void CTabBootload::ChangeAbortStatus(bool fSaveContext)
{
    static BOOL s_fLoad = true;
    static BOOL s_fSave = false;
    static BOOL s_fProgram = false;
    static BOOL s_fExecute = false;
    static BOOL s_fRead = false;
    static BOOL s_fErase = false;

    // if fSaveContext, enable abort and save cmdContext
    // if !fSaveContext, disable abort and restore cmd Context
    if(fSaveContext)
    {
        s_fLoad = m_btnLoad.IsWindowEnabled();
        s_fSave = m_btnSave.IsWindowEnabled();
        s_fProgram = m_btnProgram.IsWindowEnabled();
        s_fExecute = m_btnExecute.IsWindowEnabled();
        s_fRead = m_btnRead.IsWindowEnabled();
        s_fErase = m_btnErase.IsWindowEnabled();

        m_btnLoad.EnableWindow(false);
        m_btnSave.EnableWindow(false);
        m_btnProgram.EnableWindow(false);
        m_btnExecute.EnableWindow(false);
        m_btnRead.EnableWindow(false);
        m_btnErase.EnableWindow(false);

        m_btnAbort.EnableWindow(true);
    }
    else
    {
        m_btnLoad.EnableWindow(s_fLoad);
        m_btnSave.EnableWindow(s_fSave);
        m_btnProgram.EnableWindow(s_fProgram);
        m_btnExecute.EnableWindow(s_fExecute);
        m_btnRead.EnableWindow(s_fRead);
        m_btnErase.EnableWindow(s_fErase);

        m_btnAbort.EnableWindow(false);
    }
}

void CTabBootload::DoDataExchange(CDataExchange* pDX)
{
	CTabDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BOOT_LOAD, m_btnLoad);
	DDX_Control(pDX, IDC_BOOT_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_BOOT_PROGRAM, m_btnProgram);
	DDX_Control(pDX, IDC_BOOT_EXEC, m_btnExecute);
	DDX_Control(pDX, IDC_BOOT_READ, m_btnRead);
	DDX_Control(pDX, IDC_BOOT_ERASE, m_btnErase);
	DDX_Control(pDX, IDC_BOOT_ABORT, m_btnAbort);
	DDX_Control(pDX, IDC_BOOT_COMBO, m_comboChannel);
	DDX_Control(pDX, IDC_BOOT_AUTOCLRLOG, m_chkAutoClrLog);
}
//+
BEGIN_MESSAGE_MAP(CTabBootload, CTabDlg)
	ON_CBN_DROPDOWN(IDC_BOOT_COMBO, &CTabBootload::OnCbnDropdownBootCombo)
	ON_CBN_SELCHANGE(IDC_BOOT_COMBO, &CTabBootload::OnCbnSelchangeBootCombo)
	ON_BN_CLICKED(IDC_BOOT_LOAD, &CTabBootload::OnBnClickedBootLoad)
	ON_BN_CLICKED(IDC_BOOT_SAVE, &CTabBootload::OnBnClickedBootSave)
	ON_BN_CLICKED(IDC_BOOT_PROGRAM, &CTabBootload::OnBnClickedBootProgram)
	ON_BN_CLICKED(IDC_BOOT_EXEC, &CTabBootload::OnBnClickedBootExec)
	ON_BN_CLICKED(IDC_BOOT_READ, &CTabBootload::OnBnClickedBootRead)
	ON_BN_CLICKED(IDC_BOOT_ERASE, &CTabBootload::OnBnClickedBootErase)
	ON_BN_CLICKED(IDC_BOOT_ABORT, &CTabBootload::OnBnClickedBootAbort)
	ON_BN_CLICKED(IDC_BOOT_AUTOCLRLOG, &CTabBootload::OnBnClickedBootAutoclrlog)
END_MESSAGE_MAP()


// CTabBootload message handlers

BOOL CTabBootload::OnInitDialog()
{
	CTabDlg::OnInitDialog();

	// TODO:  Add extra initialization here
	m_logo.CreateFromAlias(this,IDC_BOOT_LOGO);

	int nAuto = theApp.GetProfileInt("settings", "AutoClearLog", 1);
	m_chkAutoClrLog.SetCheck(nAuto);

	UpdateControls();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CTabBootload::OnCbnDropdownBootCombo()
{
	theApp.m_DeviceMgr.Refresh();
	UpdateControls();
	m_comboChannel.ResetContent();
	theApp.m_DeviceMgr.FillDeviceCombo(m_comboChannel);
}

void CTabBootload::OnCbnSelchangeBootCombo()
{
	int nSel = m_comboChannel.GetCurSel();
	if(nSel >= 0)
	{
		CString sSel;
		m_comboChannel.GetLBText(nSel, sSel);
		if(theApp.m_DeviceMgr.SelectDevice(sSel))
		{
			theApp.SetStatusMessage("Connecting to board...");
			if (theApp.m_DeviceMgr.OpenDevice()) 
			{
				theApp.SetStatusMessage("USB Bootloader Firmware Version " + theApp.m_DeviceMgr.ReadVersion() );
				theApp.m_DeviceMgr.CloseDevice();
			}
		}
	}
	UpdateControls();
}

CString DoFileDialog(BOOL fOpen, CWnd* pParent)
{
	CString sFile;
	LPCSTR psFilter = "HEX files|*.hex|All files (*.*)|*.*||";
	DWORD dwFlags = fOpen? (OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST) : (OFN_OVERWRITEPROMPT);
	CFileDialog dlg(fOpen, "hex", "*.hex", dwFlags, psFilter, pParent);
	dlg.m_ofn.lpstrTitle = fOpen?"Choose HEX file to load":"Safe HEX As...";
	if(IDOK == dlg.DoModal())
		sFile = dlg.GetPathName();
	return sFile;
}

void CTabBootload::OnBnClickedBootLoad()
{
	InProcedure(true);

	theApp.SetStatusMessage("Loading HEX file...");
	CString sFile = DoFileDialog(TRUE, this);
	if(!sFile.IsEmpty())
	{
		theApp.ShowMessage(FmtStr("Loading %s...", sFile));
		if(m_hexfile.ImportP18HEXFile(sFile))
		{
			CheckConfiguration();
			if(m_hexfile.IsEmpty())
				theApp.ShowWarning("No HEX file data.");
			else
				ShowHexContent();
		}
		else
		{
			if(!theApp.m_DeviceMgr.m_fAbortOperation)
				theApp.ShowWarning("Failed to load file.");
		}
	}
	InProcedure(false);
}

void CTabBootload::OnBnClickedBootSave()
{
	InProcedure(true);

	CString sFile = DoFileDialog(FALSE, this);
	if(!sFile.IsEmpty())
		m_hexfile.ExportP18HEXFile(sFile);

	InProcedure(false);
}

void CTabBootload::OnBnClickedBootProgram()
{
	InProcedure(true);

	bool fOK = false;

	if(theApp.m_DeviceMgr.OpenDevice())
	{
		fOK = true;
		CHexMemGroup* pmg = m_hexfile.GetGroup(MG_PGM);
		if(pmg)
		{
			if(theApp.m_DeviceMgr.EraseMem(MG_PGM))
			{
				WORD wGrpSegAddr = pmg->GetGroupSegmentAddr();
				WORD wGrpBaseAddr = pmg->GetGroupOffsetBaseAddr();
				MEMBLOCKENUM mbe;
				while(pmg->EnumBlocks(mbe))
				{
					WORD wBlkBaseAddr = mbe.pmb->m_wBaseAddr;
					DWORD dwAddr = MAKELONG(wGrpSegAddr, (wGrpBaseAddr+wBlkBaseAddr));
#define OPTIMIZE_PROGRAM_MEM_WRITE 1
#if OPTIMIZE_PROGRAM_MEM_WRITE
					// An optimization to speed write time:
					// Because we just erased the entirety of program mem (set all to 0xFF), it's
					//   a waste of time to reprogram any bytes with 0xFF. We can save quite a 
					//   bit of time if, before writing, we scanned the to-be-written data, 
					//   found the last non-0xFF byte, then truncated the data at that point.
					// The savings is profound when you read the device then reprogram it 
					//   with the just-read data. The stock demo f/w is only 4512 (0x11A0) 
					//   bytes long (0x19A0 total bytes less the initial 0x800 boot block that 
					//   we skip), thus it's MUCH faster to write only that 7% of memory 
					//   (4512/64k) that is actually non-0xFF.
					LPCBYTE pChk = mbe.pmb->m_data;
					DWORD dwCount = mbe.pmb->m_data.GetCount();
					DWORD dwIdx=0;
					while(dwCount>=0)
					{
						if(0xFF != pChk[dwCount-1])
							break;
						dwCount--;
					}
					CByteBuf bbWrite(pChk, dwCount);
					fOK &= theApp.m_DeviceMgr.WriteFLASH(dwAddr, bbWrite);
#else
					// Non-optimized: Write the entirety of supplied data
					fOK &= theApp.m_DeviceMgr.WriteFLASH(dwAddr, mbe.pmb->m_data);
#endif
				}
			}
			else
				fOK = false;
		}

		// Program EEPROM
		if(fOK)
		{
			if(m_hexfile.GetGroup(MG_EE, pmg))
			{
				MEMBLOCKENUM mbe;
				while(pmg->EnumBlocks(mbe))
					fOK &= theApp.m_DeviceMgr.WriteEEDATA(mbe.pmb->m_data);
			}
		}

		// Program USER ID Data
		if(fOK)
		{
			if(m_hexfile.GetGroup(MG_UID, pmg))
			{
				if(theApp.m_DeviceMgr.EraseMem(MG_UID))
				{
					MEMBLOCKENUM mbe;
					while(pmg->EnumBlocks(mbe))
						fOK &= theApp.m_DeviceMgr.WriteUID(mbe.pmb->m_data);
				}
				else
					fOK = false;
			}
		}

		// Program CONFIG Data
		if(fOK)
		{
			if(m_hexfile.GetGroup(MG_CFG, pmg))
			{
				MEMBLOCKENUM mbe;
				while(pmg->EnumBlocks(mbe))
					fOK &= theApp.m_DeviceMgr.WriteCONFIG(mbe.pmb->m_data);
			}
		}

		// Note that we don't program DeviceID memory even if m_hexfile contains it.
		// The DeviceID is burned into the chip at manufacture time and is read-only.

		if(fOK)
			theApp.ShowMessage("Programming successful!");

		theApp.m_DeviceMgr.CloseDevice();
	}

	InProcedure(false);
}

void CTabBootload::OnBnClickedBootExec()
{
	if (theApp.m_DeviceMgr.OpenDevice())
	{
		if(theApp.m_DeviceMgr.ResetBoard())
			theApp.ShowMessage("Board has been Reset");
		else
			theApp.ShowWarning("Failed to Reset board");
		theApp.m_DeviceMgr.CloseDevice();
	}
}

static void FormatMemoryDump(CString &FormatBuffer, DWORD StartAddress, BYTE *ByteBuffer, DWORD Length)
{
     DWORD Offset = StartAddress%16;
     DWORD Address = StartAddress-Offset;

     FormatBuffer = "";
     for (DWORD i = 0; i < (Length+Offset); i++)
     {
     if ( (Address+i) % 0x10 == 0)
            FormatBuffer += FmtStr("\r\n%06X ",Address+i);
     if (Address+i < StartAddress)
        FormatBuffer += FmtStr("%02X ",0xFF);
     else
        FormatBuffer += FmtStr("%02X ",ByteBuffer[i-Address]);
     }
}

void CTabBootload::InProcedure(bool fStart)
{
	m_fBusy = fStart;

	if(fStart && m_chkAutoClrLog.GetCheck())
		theApp.ClearLog();

	ChangeAbortStatus(fStart?SAVE_CONTEXT:RESTORE_CONTEXT);
	UpdateControls();
	if(!fStart && theApp.m_DeviceMgr.m_fAbortOperation)
		theApp.ShowMessage("Operation Aborted.");
	else
		theApp.SetStatusReady();
	theApp.m_DeviceMgr.m_fAbortOperation = false;
}

void CTabBootload::OnBnClickedBootRead()
{
	InProcedure(true);

	CString sListing;

	m_hexfile.Empty();

	theApp.ShowMessage("Reading Device...");

	if(theApp.m_DeviceMgr.OpenDevice())
	{
		CByteBuf* pbaPgm = theApp.m_DeviceMgr.ReadFLASH(PIC_PGM_SEGADDR, PIC18F4550_ROMSIZE);
		CByteBuf* pbaEE = theApp.m_DeviceMgr.ReadEEDATA(0, PIC18F4550_EESIZE);
		CByteBuf* pbaUID = theApp.m_DeviceMgr.ReadCONFIG(PIC_UID_SEGADDR, PIC18F4550_UIDSIZE);
		CByteBuf* pbaCfg = theApp.m_DeviceMgr.ReadCONFIG(PIC_CFG_SEGADDR, PIC18F4550_CFGSIZE);
		CByteBuf* pbaDID = theApp.m_DeviceMgr.ReadCONFIG(PIC_REGADDR_DEVID1, 2);

		if(!theApp.m_DeviceMgr.m_fAbortOperation && pbaPgm && pbaEE && pbaUID && pbaCfg && pbaDID)
		{
			m_hexfile.SetGroupData(MG_PGM, *pbaPgm);
			m_hexfile.SetGroupData(MG_EE, *pbaEE);
			m_hexfile.SetGroupData(MG_UID, *pbaUID);
			m_hexfile.SetGroupData(MG_CFG, *pbaCfg);
			m_hexfile.SetGroupData(MG_DEVID, *pbaDID);
			m_hexfile.ForceValid();	// Assume that if the data came from the chip, it's valid
		}
		else
		{
			if(!theApp.m_DeviceMgr.m_fAbortOperation)
				theApp.ShowWarning("Failed to read");
			m_hexfile.Empty();
		}

		delete pbaPgm;
		delete pbaEE;
		delete pbaUID;
		delete pbaCfg;
		delete pbaDID;

		if(!m_hexfile.IsEmpty())
		{
			ShowHexContent();
			theApp.ShowMessage("Read Completed");
		}
		theApp.m_DeviceMgr.CloseDevice();
		theApp.SetStatusReady();
	}
	else
	{
		theApp.ShowWarning("Failed to open device");
	}

	InProcedure(false);
}

void CTabBootload::OnBnClickedBootErase()
{
	InProcedure(true);

	if(theApp.m_DeviceMgr.OpenDevice())
	{
		theApp.ShowMessage(FmtStr("Erasing Flash from 0x%04X to 0x%04X...", USER_FLASH_BASE_ADDR, PIC18F4550_MAXROM));
		if (theApp.m_DeviceMgr.EraseMem(MG_PGM))
		{
			theApp.ShowMessage(FmtStr("Verifying Flash from 0x%04X to 0x%04X...", USER_FLASH_BASE_ADDR, PIC18F4550_MAXROM));
			CByteBuf* pbb = theApp.m_DeviceMgr.ReadFLASH(USER_FLASH_BASE_ADDR, USER_FLASH_SIZE);
			if(pbb)
			{
				int nr = pbb->GetCount();
				if(USER_FLASH_SIZE == nr)
				{
					BYTE empty[USER_FLASH_SIZE];
					memset(empty, 0xFF, sizeof(empty));	// This is what the buffer SHOULD look like
					LPCBYTE pData = pbb->GetData();
					if((USER_FLASH_SIZE == nr) && !memcmp(pData, empty, USER_FLASH_SIZE))
					{
						theApp.ShowMessage("Erase Completed and Verified.");
					}
					else
					{
						for (int i=0; i<nr; i++)
						{
							if (pData[i] != 0xFF)
							{
								theApp.ShowWarning(FmtStr("Failed at Address 0x%06X: Expected(0xFF) Actual(0x%02X)", (USER_FLASH_BASE_ADDR+i), pData[i]));
								break;
							}
						}
					}
				}
				else
				{
					theApp.ShowWarning("Failed to read all mem for verification.");
				}
				delete pbb;
			}
			else 
			{
				theApp.ShowWarning("Failed to read for verification.");
			}
		}
		else
		{
			theApp.ShowWarning("Failed to erase.");
		}

		theApp.m_DeviceMgr.CloseDevice();
	}
	InProcedure(false);

}

void CTabBootload::OnBnClickedBootAbort()
{
	theApp.SetStatusMessage("Aborting...");
	theApp.ProcessMessages();
	theApp.m_DeviceMgr.m_fAbortOperation = true;
}

void CTabBootload::OnBnClickedBootAutoclrlog()
{
	bool fAuto = (BST_CHECKED==m_chkAutoClrLog.GetCheck());
	theApp.WriteProfileInt("settings", "AutoClearLog", fAuto);
}
