//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PD_FSUSB.rc
//
#define IDD_PD_FSUSB_DIALOG             102
#define IDD_TABDLG                      103
#define IDR_MAINFRAME                   128
#define IDD_TAB_BOOT                    129
#define IDD_TAB_DEMO                    130
#define IDB_POT_BG                      130
#define IDB_TEMP_BG_C                   131
#define IDB_TEMP_BG_F                   132
#define IDB_LOGO                        133
#define IDB_BTN_LOAD                    134
#define IDB_BTN_SAVE                    135
#define IDB_BTN_PROGRAM                 136
#define IDB_BTN_EXECUTE                 137
#define IDB_BTN_READ                    138
#define IDB_BTN_ERASE                   139
#define IDB_BTN_LOAD6                   140
#define IDB_BTN_ABORT                   140
#define IDC_TABS                        1001
#define IDC_DEMO_COMBO                  1002
#define IDC_RADIO1                      1003
#define IDC_DEMO_TEMP_REAL              1003
#define IDC_EDIT1                       1004
#define IDC_DEMO_TEMP_VAL               1004
#define IDC_LOG                         1004
#define IDC_RADIO2                      1005
#define IDC_DEMO_TEMP_LOG               1005
#define IDC_BUTTON1                     1006
#define IDC_DEMO_TEMP_LOG_ACQUIRE       1006
#define IDC_CLEAR_LOG                   1006
#define IDC_BOOT_LOAD                   1006
#define IDC_BOOT_SAVE                   1007
#define IDC_BOOT_PROGRAM                1008
#define IDC_DEMO_POTVALUEDIAL           1009
#define IDC_BOOT_EXEC                   1009
#define IDC_DEMO_POT_RES                1010
#define IDC_BOOT_READ                   1010
#define IDC_BUTTON6                     1011
#define IDC_BOOT_ABORT                  1011
#define IDC_DEMO_LED4                   1012
#define IDC_BOOT_ERASE                  1012
#define IDC_DEMO_LED3                   1013
#define IDC_DEMO_CONNECT                1014
#define IDC_DEMO_TEMPGRAPH              1015
#define IDC_STATUS                      1016
#define IDC_DEMO_UNIT_C                 1019
#define IDC_RADIO4                      1020
#define IDC_DEMO_UNIT_F                 1020
#define IDC_BOOT_LOGO                   1024
#define IDC_BOOT_COMBO                  1025
#define IDC_CHECK1                      1026
#define IDC_BOOT_AUTOCLRLOG             1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
