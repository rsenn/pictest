// PD_FSUSBDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include "MyTabCtrl.h"
#include "TabBootload.h"
#include "TabDemo.h"
#include "afxwin.h"

// CPD_FSUSBDlg dialog
class CPD_FSUSBDlg : public CDialog
{
// Construction
public:
	CPD_FSUSBDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CPD_FSUSBDlg();

// Dialog Data
	enum { IDD = IDD_PD_FSUSB_DIALOG };

	void SetStatus(LPCSTR psMsg);
	void ShowWarning(LPCSTR ps);
	void ShowMessage(LPCSTR ps);
	void Logln(LPCSTR ps);
	void ClearLog();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;
	CMyTabCtrl m_tabs;
	CFixedFontEdit m_log;
	CTabBootload* m_pDlgBoot;
	CTabDemo* m_pDlgDemo;
	HDEVNOTIFY m_hDevNotify;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedClearLog();
	afx_msg LRESULT OnDeviceChange(WPARAM,LPARAM);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
