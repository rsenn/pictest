#pragma once
#include "TabDlg.h"
#include "BmpCtrl.h"
#include "BmpButton.h"
#include "HexFile.h"
#include "afxwin.h"

// CTabBootload dialog

class CTabBootload : public CTabDlg
{
	DECLARE_DYNAMIC(CTabBootload)

public:
	CTabBootload();
	virtual ~CTabBootload();

	virtual void Activate(bool fActivate);
	virtual void SetAutoConnect(bool fAuto);

// Dialog Data
	enum { IDD = IDD_TAB_BOOT };

protected:
	CHexFile m_hexfile;
	bool m_fBusy;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	void InProcedure(bool fStart);
	void UpdateControls();
	void CheckConfiguration();
	void ShowHexContent();
	void ChangeAbortStatus(bool fSaveContext);

	DECLARE_MESSAGE_MAP()
public:
	CBmpCtrl m_logo;
	virtual BOOL OnInitDialog();
	CBmpButton m_btnLoad;
	CBmpButton m_btnSave;
	CBmpButton m_btnProgram;
	CBmpButton m_btnExecute;
	CBmpButton m_btnRead;
	CBmpButton m_btnErase;
	CBmpButton m_btnAbort;
	CComboBox m_comboChannel;
	afx_msg void OnCbnDropdownBootCombo();
	afx_msg void OnCbnSelchangeBootCombo();
	afx_msg void OnBnClickedBootLoad();
	afx_msg void OnBnClickedBootSave();
	afx_msg void OnBnClickedBootProgram();
	afx_msg void OnBnClickedBootExec();
	afx_msg void OnBnClickedBootRead();
	afx_msg void OnBnClickedBootErase();
	afx_msg void OnBnClickedBootAbort();
	afx_msg void OnBnClickedBootAutoclrlog();
	CButton m_chkAutoClrLog;
};
