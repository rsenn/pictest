#pragma once

#include "..\MPUSBAPI\mpusbapi_vc.h"

class CMpUsbApiWrapper
{
public:
	CMpUsbApiWrapper(void);
	~CMpUsbApiWrapper(void);

	DWORD GetDLLVersion(void);
	DWORD GetDeviceCount(PCHAR pVID_PID);
	HANDLE Open(IN DWORD instance, IN PCHAR pVID_PID, IN PCHAR pEP, IN DWORD dwDir, IN DWORD dwReserved);
	DWORD Read(IN HANDLE handle, IN PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds);
	DWORD Write(IN HANDLE handle, IN PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds);
	DWORD ReadInt(IN HANDLE handle, PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds);
	BOOL Close(IN HANDLE handle);

protected:
	HMODULE m_hLib;
	FARPROC	m_pfnMPUSBGetDLLVersion,
			m_pfnMPUSBGetDeviceCount,
			m_pfnMPUSBOpen,
			m_pfnMPUSBRead,
			m_pfnMPUSBWrite,
			m_pfnMPUSBReadInt,
			m_pfnMPUSBClose;
};
