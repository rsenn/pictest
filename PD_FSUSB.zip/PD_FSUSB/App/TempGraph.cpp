// TempGraph.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "TempGraph.h"

#define	GRID_PX	14			// Grid is 14 x 14px
#define X_MIN	8			// Min X-value for red line
#define	X_MAX	190			// Max X-value for red line
#define	Y_36	12			// Y-value for 36 degrees
#define	Y_MIN	Y_36		// Min Y-value for red line
#define	Y_DEG	GRID_PX/2	// #px per degree
#define	Y_MAX	152			// Max Y-value for red line (==16 degrees)
#define	X_INC	(GRID_PX/2)	// Two samples per x-grid
#define	DISP_STEP_PX	4

// CTempGraph

IMPLEMENT_DYNAMIC(CTempGraph, CBmpCtrl)

CTempGraph::CTempGraph() :
	CBmpCtrl(0),	// no default bg bmp
	m_fCelsius(true)
{
	m_imgC.LoadFromResource( AfxGetInstanceHandle(), IDB_TEMP_BG_C);
	m_imgF.LoadFromResource( AfxGetInstanceHandle(), IDB_TEMP_BG_F);

	COLORREF crDisbl = GetSysColor(COLOR_3DDKSHADOW);
	m_imgDisblC.LoadFromResource( AfxGetInstanceHandle(), IDB_TEMP_BG_C);
	m_imgDisblC.SwapBitmapColor(RGB(0,0xff,0), crDisbl);
	m_imgDisblC.SwapBitmapColor(RGB(0,128,0), crDisbl);

	m_imgDisblF.LoadFromResource( AfxGetInstanceHandle(), IDB_TEMP_BG_F);
	m_imgDisblF.SwapBitmapColor(RGB(0,0xff,0), crDisbl);
	m_imgDisblF.SwapBitmapColor(RGB(0,128,0), crDisbl);

	ZeroMemory(m_data, sizeof(m_data));
}

CTempGraph::~CTempGraph()
{
}

void CTempGraph::ShowCelsius(bool fCelsius)
{
	m_fCelsius = fCelsius;
	Invalidate();
}

void CTempGraph::AddDatum(double dTemp)
{
	ASSERT(dTemp < 36.0);
	memmove(&m_data[1], &m_data[0], ((NPTS-1)*sizeof(m_data[0])));
	m_data[0] = dTemp;
	Invalidate();
}

void CTempGraph::ClearData()
{
	ZeroMemory(m_data, sizeof(m_data));
}

int CTempGraph::GetGraphY(int idx)
{
	double t = m_data[idx];	// m_data is celsius
	if(!m_fCelsius)
	{
		// Convert to F
		t = ((t*9.0)/5.0)+32.0;
		// Adjust value to F graph scale
		t = (((double)t-67.0)/1.11)+67.0;
		// Convert back to C (al drawing done in C, even when mode is F)
		t = (t-32.0)*(5.0/9.0);
	}

	double offset = 36.0 - t;
	return Y_36 + (int)(offset*(Y_DEG));
}

CImage* CTempGraph::GetBgImg()
{
	CImage* pImg = NULL;
	if(IsWindowEnabled())
		pImg = m_fCelsius ? &m_imgC : &m_imgF;
	else
		pImg = m_fCelsius ? &m_imgDisblC : &m_imgDisblF;
	return pImg;
}

// Called by CBmpCtrl::OnPaint() after the bg bmp has been painted
void CTempGraph::PostPaintBg(CPaintDC& dc)		
{
	int x = X_MAX;

	COLORREF crPen = GetSysColor(COLOR_3DSHADOW);
	if(IsWindowEnabled())
		crPen = RGB(0xff, 0x00, 0x00);
	CPen pen(PS_SOLID, 1, crPen);
	CPen* pOldPen = dc.SelectObject(&pen);
	dc.MoveTo(x,GetGraphY(0));
	for(int n=1; ((n<NPTS)&&(x>X_MIN)&&m_data[n]); n++)
	{
		x -= DISP_STEP_PX;
		x = max(x, (X_MIN+1));
		dc.LineTo(x,GetGraphY(n));
	}
	dc.SelectObject(pOldPen);
}

BEGIN_MESSAGE_MAP(CTempGraph, CBmpCtrl)
END_MESSAGE_MAP()

// CTempGraph message handlers

void CTempGraph::PreSubclassWindow()
{
	ResizeToImg(&m_imgC);
	CBmpCtrl::PreSubclassWindow();
}
