#pragma once

// In the Boot firmware's "boot.h" file you'll fine this def:
#define RM_RESET_VECTOR             0x000800
// Here's a def that is more understandable in the context of this code:
#define USER_FLASH_BASE_ADDR		RM_RESET_VECTOR
// It's setting the base addr for the f/w that the bootloader 
//   installs (when driven by e.g. this Windows App).
// Therefore, when we perform any write operation to the chip, 
//   we must begin writing at address 0x800. If we tried to write 
//   to any address lower than 0x800 it would fail because the boot 
//   firmware address space (0x000 - 0x7ff) is write-protected.
// This write-protection is validated in the function
//   CTabBootload::CheckConfiguration() - search this file for 
//   "Table Write Protect".
// The PICDEM FS USB boot code is actually 0x7E0 bytes long - 
//   they were able to squeeze it into the boot block with only 
//   0x20 bytes to spare :)

// Here's another useful def that doesn't seem to be in any of the MChip file:
#define PIC18F4550_MAXROM	0x7FFF
#define PIC18F4550_ROMSIZE	(PIC18F4550_MAXROM+1)
// The PIC18F4550's program memory address space is 0x0000 thru 0x7FFF: 0x8000 
//   (32768 == 32K) bytes. Any attempt for this bootloader to write to an 
//   address greater than 0x7FFF will fail.

// So then, given the two defs above, the size of the "user writable" (via e.g. 
//   this app) area in the device is 0x7800 (>30K... still frickin' huge)
#define	USER_FLASH_SIZE (PIC18F4550_ROMSIZE-USER_FLASH_BASE_ADDR)

// Pic PIC18F2455/2550/44554550 have 256 bytes of EEPROM
#define PIC18F4550_EESIZE	0x100

// User-writeable ID values
#define PIC18F4550_UIDSIZE	0x08

// Configuration settings
#define PIC18F4550_CFGSIZE	0x0E	// (14 decimal)



#define picdemfs_boot       "vid_04d8&pid_000b"
#define picdemfs_demo       "vid_04d8&pid_000c"
#define bulk_out            "\\MCHP_EP1"
#define bulk_in             "\\MCHP_EP1"

typedef enum
{
	PDMODE_BOOT=0,	// Must be 0
	PDMODE_DEMO=1,	// Must be 1
	PDMODE_UNKNOWN=99,
} PDMODE;

// Commands sent to the firmware
typedef enum
{
	// Bootloader commands
	CMD_READ_VERSION		= 0x00,
	CMD_READ_FLASH			= 0x01,
	CMD_WRITE_FLASH			= 0x02,
	CMD_ERASE_FLASH			= 0x03,
	CMD_READ_EEDATA			= 0x04,
	CMD_WRITE_EEDATA		= 0x05,
	CMD_READ_CONFIG			= 0x06,
	CMD_WRITE_CONFIG		= 0x07,

	// Demo commands
	CMD_ID_BOARD			= 0x31,
	CMD_UPDATE_LED			= 0x32,
	CMD_SET_TEMP_REAL		= 0x33,
	CMD_RD_TEMP				= 0x34,
	CMD_SET_TEMP_LOGGING	= 0x35,
	CMD_RD_TEMP_LOGGING		= 0x36,
	CMD_RD_POT				= 0x37,

	// Common to all
	CMD_RESET				= 0xFF,
} FWCMD;

// The base addresses for the various memory segments inside the PIC18F4550
#define PIC_PGM_SEGADDR		0x00000000		// Actually 0x00000000 thru 0x001F0000
#define PIC_UID_SEGADDR		0x00200000
#define PIC_CFG_SEGADDR		0x00300000
#define PIC_EE_SEGADDR		0x00F00000
#define PIC_DEVID_SEGADDR	0x003F0000		// Only 2 bytes of devi; their addresses defined below

// Addresses of specific registers (memory locations) used by this app
#define PIC_REGADDR_DEVID1		(PIC_DEVID_SEGADDR | 0xFFFE)
#define PIC_REGADDR_DEVID2		(PIC_DEVID_SEGADDR | 0xFFFF)

#define PIC_REGADDR_CONFIG1L	(PIC_CFG_SEGADDR)
#define PIC_REGADDR_CONFIG1H	(PIC_CFG_SEGADDR+0x1)
#define PIC_REGADDR_CONFIG2L	(PIC_CFG_SEGADDR+0x2)
#define PIC_REGADDR_CONFIG2H	(PIC_CFG_SEGADDR+0x3)
#define PIC_REGADDR_CONFIG3L	(PIC_CFG_SEGADDR+0x4)
#define PIC_REGADDR_CONFIG3H	(PIC_CFG_SEGADDR+0x5)
#define PIC_REGADDR_CONFIG4L	(PIC_CFG_SEGADDR+0x6)
#define PIC_REGADDR_CONFIG4H	(PIC_CFG_SEGADDR+0x7)
#define PIC_REGADDR_CONFIG5L	(PIC_CFG_SEGADDR+0x8)
#define PIC_REGADDR_CONFIG5H	(PIC_CFG_SEGADDR+0x9)
#define PIC_REGADDR_CONFIG6L	(PIC_CFG_SEGADDR+0xA)
#define PIC_REGADDR_CONFIG6H	(PIC_CFG_SEGADDR+0xB)
#define PIC_REGADDR_CONFIG7L	(PIC_CFG_SEGADDR+0xC)
#define PIC_REGADDR_CONFIG7H	(PIC_CFG_SEGADDR+0xD)



// The various areas of the chip's memory
typedef enum
{
	// The assigned value is the segment's base address
	MG_PGM=0x0000,		// Program memory, 0x00 thru 0x1F
	MG_UID=0x0020,		// UserID memory
	MG_CFG=0x0030,		// Config data
	MG_DEVID=0x003F,	// DeviceID memory
	MG_EE=0x00F0,		// EEPROM memory
	MG_UNKNOWN=0xFFFF,	// ???
} MEMGRP;


// PIC18Fxxxx can erase 64 bytes of data at a time
#define ERASE_BLOCK_SIZE	64

// The 18F4550 can actually program 32 bytes at a time.
// However, because the lame-o original version of the FSUSB Windows app managed 
//    the mem in 16-byte chunks, we're stuck with doing it 16 bytes at a time.
// See the comment in the boot fw's WriteProgMem() in boot.c
#define PGM_BLOCK_SIZE	16

