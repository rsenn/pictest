// PotValueDial.cpp : implementation file
//

#include "stdafx.h"
#include <complex>	//sin, cos
#include "PD_FSUSB.h"
#include "PotValueDial.h"


// CPotValueDial

IMPLEMENT_DYNAMIC(CPotValueDial, CBmpCtrl)

CPotValueDial::CPotValueDial() :
	CBmpCtrl(IDB_POT_BG),
	m_nValue(-1)
{
	COLORREF crDisbl = GetSysColor(COLOR_3DDKSHADOW);
	m_imgDisbl.LoadFromResource( AfxGetInstanceHandle(), IDB_POT_BG);
	m_imgDisbl.SwapBitmapColor(RGB(0,0xff,0), crDisbl);
	m_imgDisbl.SwapBitmapColor(RGB(0,0x80,0), crDisbl);
	m_imgDisbl.SwapBitmapColor(RGB(0xff,0,0), crDisbl);
}

CPotValueDial::~CPotValueDial()
{
}

POINT ComputePoint(double degrees, double radius)
{
	double pi = 3.14159265359;
	double ctr = 65.5;

	double rads = (degrees) * (pi/180);
	double zcos = cos ( rads );	//x
	double zsin = sin ( rads );	//y

	POINT pt;
	pt.x = (int)(ctr + (radius*zcos));
	pt.y = (int)(ctr + (radius*zsin));
	return pt;
}

// Called by CBmpCtrl::OnPaint() after the bg bmp has been painted
void CPotValueDial::PostPaintBg(CPaintDC& dc)
{
	if(IsWindowEnabled() && (m_nValue>=0))
	{
		CPen pen(PS_SOLID, 1, RGB(0xff, 0x00, 0x00));
		CPen* pOldPen = dc.SelectObject(&pen);
		//0 ohms = -202 degrees
		//10k ohms = 21 degrees

		double tipDegrees =  (((double)m_nValue/(double)10000)*(double)223)-(double)202;
		POINT ptStart = ComputePoint(tipDegrees-30, 4);
		POINT ptTip = ComputePoint(tipDegrees, 48);
		POINT ptCtr = ComputePoint(tipDegrees, 4);
		POINT ptEnd = ComputePoint(tipDegrees+30, 4);

		dc.MoveTo(ptStart.x,ptStart.y);
		dc.LineTo(ptTip.x, ptTip.y);
		dc.LineTo(ptEnd.x, ptEnd.y);

		dc.MoveTo(ptCtr.x,ptCtr.y);
		dc.LineTo(ptTip.x, ptTip.y);

		dc.SelectObject(pOldPen);
	}
}

void CPotValueDial::SetValue(int nValue)
{
	m_nValue = min(nValue, 10000);
	m_nValue = max(m_nValue, 0);
	Invalidate();
}


BEGIN_MESSAGE_MAP(CPotValueDial, CBmpCtrl)
	ON_WM_PAINT()
	ON_WM_ENABLE()
END_MESSAGE_MAP()


// CPotValueDial message handlers


void CPotValueDial::OnEnable(BOOL bEnable)
{
	if(!bEnable)
		m_nValue = -1;
	CBmpCtrl::OnEnable(bEnable);	// Calls Invalidate();
}
