#pragma once


// CFixedFontEdit

class CFixedFontEdit : public CEdit
{
	DECLARE_DYNAMIC(CFixedFontEdit)

public:
	CFixedFontEdit();
	virtual ~CFixedFontEdit();

protected:
	CFont m_font;
	DECLARE_MESSAGE_MAP()
	virtual void PreSubclassWindow();
};


