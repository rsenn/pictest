#pragma once

#include "BmpCtrl.h"
#include "DisabledImage.h"

// CTempGraph

#define NPTS	50	// # of celsius temp samples to store

class CTempGraph : public CBmpCtrl
{
	DECLARE_DYNAMIC(CTempGraph)

public:
	CTempGraph();
	virtual ~CTempGraph();

	void ShowCelsius(bool fCelsius);
	void AddDatum(double dTemp);
	void ClearData();

protected:
	bool m_fCelsius;
	CImage m_imgC, m_imgF;
	CDisabledImage m_imgDisblC, m_imgDisblF;
	double m_data[NPTS];

	int GetGraphY(int idx);

	DECLARE_MESSAGE_MAP()

	virtual CImage* GetBgImg();
	virtual void PostPaintBg(CPaintDC& dc);

	virtual void PreSubclassWindow();
};


