#include "StdAfx.h"
#include "DisabledImage.h"

CDisabledImage::CDisabledImage(void)
{
}

CDisabledImage::~CDisabledImage(void)
{
}

void CDisabledImage::SwapBitmapColor(int ColorOld, int ColorNew)
{
	for(int y=0;y<this->GetHeight();y++) {
		for(int x=0;x<this->GetWidth();x++) {
			if(this->GetPixel(x,y)==ColorOld)
				this->SetPixel(x,y,ColorNew);
		}
	}
}
void CDisabledImage::PreserveBitmapColor(int ColorSave, int ColorNew)
{
	for(int y=0;y<this->GetHeight();y++) {
		for(int x=0;x<this->GetWidth();x++) {
			if(this->GetPixel(x,y)!=ColorSave)
				this->SetPixel(x,y,ColorNew);
		}
	}
}
void CDisabledImage::ConvertColors(COLORREF crTarget, COLORREF* pcrSwap, int nSwap, int nClrIndex)
{
	ASSERT((HBITMAP)*this);									// Image must have already been loaded
	for(int n=0; n<nSwap; n++)
		SwapBitmapColor(pcrSwap[n], crTarget);				// Replace pcrSwap[n] with the target color
	PreserveBitmapColor(crTarget, DEFAULT_TRANSP_COLOR);	// Drop out all but target color
	SwapBitmapColor(crTarget, GetSysColor(nClrIndex));		// Target color to desired final "disabled" color
}
