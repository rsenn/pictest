#pragma once


// CLed

class CLed : public CStatic
{
	DECLARE_DYNAMIC(CLed)

public:
	CLed();
	virtual ~CLed();

	BOOL IsOn()	{return m_fOn;}

protected:
	BOOL m_fOn;
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnStnClicked();
	afx_msg void OnEnable(BOOL bEnable);
};


