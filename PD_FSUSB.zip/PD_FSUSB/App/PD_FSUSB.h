// PD_FSUSB.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols
#include "DeviceManager.h"
#include "MpUsbApiWrapper.h"


// CPD_FSUSBApp:
// See PD_FSUSB.cpp for the implementation of this class
//

class CPD_FSUSBApp : public CWinApp
{
public:
	CPD_FSUSBApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation
	DeviceManager m_DeviceMgr;
	CMpUsbApiWrapper MPUSB;
	void SetStatusMessage(LPCSTR psMsg);
	void SetStatusReady()					{ SetStatusMessage("Ready"); }
	void ShowWarning(LPCSTR ps);
	void ShowMessage(LPCSTR ps);
	void Logln(LPCSTR ps=NULL);
	void ClearLog();

	void ProcessMessages();

	DECLARE_MESSAGE_MAP()
};

extern CPD_FSUSBApp theApp;

extern CString FmtStr(LPCSTR psFmt, ...);
