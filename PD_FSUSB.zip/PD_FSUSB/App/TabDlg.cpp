// TabDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "TabDlg.h"


// CTabDlg dialog

IMPLEMENT_DYNAMIC(CTabDlg, CDialog)

CTabDlg::CTabDlg(UINT nIDTemplate) :
	m_fAutoConnect(false),
	CDialog(nIDTemplate, NULL)
{
}

CTabDlg::~CTabDlg()
{
}

BOOL CTabDlg::CreateTab(CWnd* pParent, int x, int y, int cx, int cy)
{
	if(!this->Create(m_lpszTemplateName, pParent))
		return FALSE;
	this->ShowWindow(SW_NORMAL);
	this->SetWindowPos(NULL, x, y, cx, cy, SWP_NOZORDER);
	return TRUE;
}

void CTabDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}
//+
BEGIN_MESSAGE_MAP(CTabDlg, CDialog)
END_MESSAGE_MAP()


// CTabDlg message handlers

BOOL CTabDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class

	return CDialog::PreTranslateMessage(pMsg);
}
