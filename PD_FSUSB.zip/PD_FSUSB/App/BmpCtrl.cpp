// BmpCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "PD_FSUSB.h"
#include "BmpCtrl.h"


// CBmpCtrl

CString CBmpCtrl::m_sClassname;

IMPLEMENT_DYNAMIC(CBmpCtrl, CWnd)

CBmpCtrl::CBmpCtrl(UINT uIdb)
{
	if(uIdb)
		m_img.LoadFromResource( AfxGetInstanceHandle(), uIdb);
}

CBmpCtrl::~CBmpCtrl()
{
}

BOOL CBmpCtrl::CreateFromAlias(CWnd* pParentDlg, UINT id)
{
	CWnd* pCtrl = pParentDlg->GetDlgItem(id);
	if(!pCtrl)
		return FALSE;

	// Remember the reference wnd's z-order position so we can put the new wnd at that location
	CWnd* pPrev = pCtrl->GetWindow(GW_HWNDPREV);

	BOOL fEnabled = pCtrl->IsWindowEnabled();

	CRect rt;
	pCtrl->GetClientRect(rt);
	rt.right++;
	rt.bottom+=2;
	CPoint offset(0,0);

	pCtrl->MapWindowPoints(pParentDlg, &offset, 1);
	pCtrl->DestroyWindow();
	rt.OffsetRect(offset);

	CString sTitle;
	sTitle.Format("CBmpCtrl_%d", id);

	// Register our classname as needed
	if (m_sClassname.IsEmpty())
	{
		UINT uStyle = (CS_BYTEALIGNCLIENT | CS_SAVEBITS | CS_HREDRAW | CS_VREDRAW);
		m_sClassname = ::AfxRegisterWndClass(uStyle, 0, NULL);
	}

	BOOL fCreated = Create(m_sClassname, sTitle, WS_CHILD|WS_VISIBLE|WS_GROUP, rt, pParentDlg, id, NULL);
	if(fCreated)
	{
		SetWindowPos(pPrev, 0,0, 0,0, (SWP_NOMOVE|SWP_NOSIZE));	// Restore z-order
		EnableWindow(fEnabled);
	}

	ResizeToImg();

	return fCreated;
}

void CBmpCtrl::ResizeToImg(CImage* pImg/*=NULL*/)
{
	if(!pImg)
		pImg = &m_img;
	if(pImg && !pImg->IsNull())
		SetWindowPos(NULL, 0,0, pImg->GetWidth(), pImg->GetHeight(), SWP_NOMOVE|SWP_NOZORDER);
}

CImage* CBmpCtrl::GetBgImg()
{
	CImage* pImg = &m_img;

	if(!IsWindowEnabled() && (HBITMAP)m_imgDisbl)
		pImg = &m_imgDisbl;

	return pImg;
}


BEGIN_MESSAGE_MAP(CBmpCtrl, CWnd)
	ON_WM_PAINT()
	ON_WM_ENABLE()
END_MESSAGE_MAP()

// CBmpCtrl message handlers

void CBmpCtrl::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CWnd::OnPaint() for painting messages

	PrePaintBg(dc);

	CImage* pBgImg = GetBgImg();

	if(pBgImg && (HBITMAP)*pBgImg)
		pBgImg->Draw(dc, 0, 0 );

	PostPaintBg(dc);
}

void CBmpCtrl::OnEnable(BOOL bEnable)
{
	CWnd::OnEnable(bEnable);

	// TODO: Add your message handler code here
	Invalidate();
}

void CBmpCtrl::PreSubclassWindow()
{
	ResizeToImg();
	CWnd::PreSubclassWindow();
}
