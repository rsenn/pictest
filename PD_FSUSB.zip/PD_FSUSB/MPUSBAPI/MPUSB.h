#pragma once

// Really a namespace, but VC's AutoComplete doesn't work on namespaces :(
class MPUSB
{
public:
	static DWORD GetDLLVersion(void);
	static DWORD GetDeviceCount(PCHAR pVID_PID);
	static HANDLE Open(DWORD instance, PCHAR pVID_PID, PCHAR pEP, DWORD dwDir, DWORD dwReserved);
	static DWORD Read(HANDLE handle, PVOID pData, DWORD dwLen, PDWORD pLength, DWORD dwMilliseconds);
	static DWORD Write(HANDLE handle,PVOID pData, DWORD dwLen, PDWORD pLength, DWORD dwMilliseconds);
	static DWORD ReadInt(HANDLE handle, PVOID pData, DWORD dwLen, PDWORD pLength, DWORD dwMilliseconds);
	static BOOL Close(HANDLE handle);

private:
	static DWORD GetDeviceLink(DWORD instance, PCHAR pVID_PID, PCHAR pPath, DWORD dwLen, PDWORD pLength);
};