// MPUSBAPI.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "MPUSBAPI.h"
#include "MPUSB.h"


#ifdef _MANAGED
#pragma managed(push, off)
#endif

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}

#ifdef _MANAGED
#pragma managed(pop)
#endif

extern "C" MPUSBAPI_API
DWORD _MPUSBGetDLLVersion(void)
{
    return MPUSB::GetDLLVersion();
}

extern "C" MPUSBAPI_API
DWORD _MPUSBGetDeviceCount(PCHAR pVID_PID)
{
	return MPUSB::GetDeviceCount(pVID_PID);
}

extern "C" MPUSBAPI_API
HANDLE _MPUSBOpen(DWORD instance,    // Input
                 PCHAR pVID_PID,    // Input
                 PCHAR pEP,         // Input
                 DWORD dwDir,       // Input
                 DWORD dwReserved) // Input <Future Use>
{
	return MPUSB::Open(instance, pVID_PID, pEP, dwDir, dwReserved);
}

extern "C" MPUSBAPI_API
DWORD _MPUSBRead(HANDLE handle,              // Input
                PVOID pData,                // Output
                DWORD dwLen,                // Input
                PDWORD pLength,             // Output
                DWORD dwMilliseconds)       // Input
{
	return MPUSB::Read(handle, pData, dwLen, pLength, dwMilliseconds);
}

extern "C" MPUSBAPI_API
DWORD _MPUSBWrite(HANDLE handle,             // Input
                 PVOID pData,               // Input
                 DWORD dwLen,               // Input
                 PDWORD pLength,            // Output
                 DWORD dwMilliseconds)      // Input
{
	return MPUSB::Write(handle, pData, dwLen, pLength, dwMilliseconds);
}

extern "C" MPUSBAPI_API
DWORD _MPUSBReadInt(HANDLE handle,           // Input
                   PVOID pData,             // Output
                   DWORD dwLen,             // Input
                   PDWORD pLength,          // Output
                   DWORD dwMilliseconds)    // Input
{
	return MPUSB::ReadInt(handle, pData, dwLen, pLength, dwMilliseconds);
}

extern "C" MPUSBAPI_API
BOOL _MPUSBClose(HANDLE handle)
{
	return MPUSB::Close(handle);
}
