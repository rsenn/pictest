// MPUSB.cpp : Defines the actual working code
//

#include "stdafx.h"
#include "MPUSBAPI.h"
#include "MPUSB.h"
#include <stdio.h>
#include <windows.h>
#include <string.h>
#include <setupapi.h>
#include <initguid.h>
#include <winioctl.h>
#include <setupapi.h>
#pragma comment( lib, "Setupapi" )

#include "ioctls.h"

#define MPUSBAPI_VERSION            0x00010000L

#define	MPUSB_DEV_NO_INFO           2
#define	MPUSB_DEV_INVALID_INST      3
#define	MPUSB_DEV_VIDPID_NOT_FOUND  4
#define MPUSB_DEV_NOT_ATTACHED      5

// MAX_NUM_MPUSB_DEV is an abstract limitation.
// It is very unlikely that a computer system will have more
// then 127 USB devices attached to it. (single or multiple USB hosts)
#define MAX_NUM_MPUSB_DEV           127


DWORD MPUSB::GetDLLVersion(void)
{
    return MPUSBAPI_VERSION;
}


DWORD MPUSB::GetDeviceCount(PCHAR pVID_PID)
{
	DWORD dwCount = 0;
	for(int i=0; i<MAX_NUM_MPUSB_DEV; i++)
	{
        if(GetDeviceLink(i,pVID_PID,NULL,0,NULL)==MPUSB_SUCCESS)
		{
			dwCount++;
		}
	}
	return dwCount;
}

HANDLE MPUSB::Open(IN DWORD instance, IN PCHAR pVID_PID, IN PCHAR pEP, IN DWORD dwDir, IN DWORD dwReserved)
{
	HANDLE hdl = INVALID_HANDLE_VALUE;
    char path[MAX_PATH];
    DWORD dwReqLen;

    // Check arguments first
    if((pVID_PID != NULL) && ((dwDir == MP_WRITE) || (dwDir == MP_READ)))
    {
        if(GetDeviceLink(instance,pVID_PID,path,MAX_PATH,&dwReqLen)==MPUSB_SUCCESS)
        {
            char path_io[MAX_PATH];
            lstrcpy(path_io,path);
            if(pEP != NULL) lstrcat(path_io,pEP);

			DWORD dwDesiredAccess = (MP_READ==dwDir)?GENERIC_READ:GENERIC_WRITE;
            hdl = CreateFile(path_io,
                                dwDesiredAccess,
                                0,
                                NULL,
                                OPEN_EXISTING,
                                FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,
                                NULL);

        }
    }
	return hdl;
}

DWORD MPUSB::Read(IN HANDLE handle, IN PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds)
{
	DWORD dwResult = MPUSB_FAIL;
    BOOL bResult;
    DWORD nBytesRead;
    OVERLAPPED gOverlapped;

    // set up overlapped structure fields
    gOverlapped.Internal     = 0;
    gOverlapped.InternalHigh = 0;
    gOverlapped.Offset       = 0;
    gOverlapped.OffsetHigh   = 0;
    gOverlapped.hEvent       = CreateEvent(NULL, FALSE, FALSE, NULL);

    if(pLength != NULL)*pLength = 0;

    // attempt an asynchronous read operation
    bResult = ReadFile(handle,pData,dwLen,&nBytesRead,&gOverlapped);

    if(!bResult)
    {
        // deal with the error code
        switch (GetLastError())
        {
            case ERROR_HANDLE_EOF:
            {
                // we have reached the end of the file
                // during the call to ReadFile
                break;
            }
            case ERROR_IO_PENDING:
            {
                // asynchronous i/o is still in progress
                switch(WaitForSingleObject(gOverlapped.hEvent, dwMilliseconds))
                {
                    case WAIT_OBJECT_0:
                        // check on the results of the asynchronous read
                        // and update the nBytesRead...
                        bResult = GetOverlappedResult(handle, &gOverlapped, &nBytesRead, FALSE);
                        if(!bResult)
                        {
                            printf("Error: %d", GetLastError());
                        }
                        else
                        {
                            if(pLength != NULL)
                                *pLength = nBytesRead;
                            dwResult = MPUSB_SUCCESS;
                        }//end if else
                        break;
                    case WAIT_TIMEOUT:
                        CancelIo(handle);
                        break;
                    default:
                        CancelIo(handle);
                        break;
                }//end switch
            }//end case
            default:
                CancelIo(handle);
                break;
        }//end switch
    }
    else
    {
        if(pLength != NULL)
            *pLength = nBytesRead;
        dwResult = MPUSB_SUCCESS;
    }//end if else

    ResetEvent(gOverlapped.hEvent);
    CloseHandle(gOverlapped.hEvent);

    return dwResult;
}

DWORD MPUSB::Write(IN HANDLE handle, IN PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds)
{
    DWORD dwResult = MPUSB_FAIL;
    BOOL bResult;
    DWORD nBytesWritten;
    OVERLAPPED gOverlapped;

    // set up overlapped structure fields
    gOverlapped.Internal     = 0;
    gOverlapped.InternalHigh = 0;
    gOverlapped.Offset       = 0;
    gOverlapped.OffsetHigh   = 0;
    gOverlapped.hEvent       = CreateEvent(NULL, FALSE, FALSE, NULL);

    if(pLength != NULL)
		*pLength = 0;

    // attempt an asynchronous read operation
    bResult = WriteFile(handle,pData,dwLen,&nBytesWritten,&gOverlapped);
    if(!bResult)
    {
        // deal with the error code
        switch (GetLastError())
        {
            case ERROR_HANDLE_EOF:
            {
                // we have reached the end of the file
                // during the call to ReadFile
                break;
            }
            case ERROR_IO_PENDING:
            {
                // asynchronous i/o is still in progress
                switch(WaitForSingleObject(gOverlapped.hEvent, dwMilliseconds))
                {
                    case WAIT_OBJECT_0:
                        // check on the results of the asynchronous read
                        // and update the nBytesWritten...
                        bResult = GetOverlappedResult(handle, &gOverlapped,
                                                      &nBytesWritten, FALSE);
                        if(!bResult)
                        {
                            printf("Error: %d", GetLastError());
                        }
                        else
                        {
                            if(pLength != NULL)
                                *pLength = nBytesWritten;
                            dwResult = MPUSB_SUCCESS;
                        }//end if else
                        break;
                    case WAIT_TIMEOUT:
                        CancelIo(handle);
                        break;
                    default:
                        CancelIo(handle);
                        break;
                }//end switch
            }//end case
            default:
                CancelIo(handle);
                break;
        }//end switch
    }
    else
    {
        if(pLength != NULL)
            *pLength = nBytesWritten;
        dwResult = MPUSB_SUCCESS;
    }//end if else

    ResetEvent(gOverlapped.hEvent);
    CloseHandle(gOverlapped.hEvent);

    return dwResult;
}

DWORD MPUSB::ReadInt(IN HANDLE handle, PVOID pData, IN DWORD dwLen, OUT PDWORD pLength, IN DWORD dwMilliseconds)
{
    DWORD dwResult = MPUSB_FAIL;

    BOOL bResult;
    DWORD nBytesRead;
    OVERLAPPED gOverlapped;

    // set up overlapped structure fields
    gOverlapped.Internal     = 0;
    gOverlapped.InternalHigh = 0;
    gOverlapped.Offset       = 0;
    gOverlapped.OffsetHigh   = 0;
    gOverlapped.hEvent       = CreateEvent(NULL, FALSE, FALSE, NULL);

    if(pLength)
		*pLength = 0;
    if(pData)
	{
		// attempt an asynchronous read operation
		bResult = DeviceIoControl(handle,
								  IOCTL_MCHPUSB_WAIT_INTERRUPT,
								  NULL,
								  0,
								  pData,
								  dwLen,
								  &nBytesRead,
								  &gOverlapped);
		if(!bResult)
		{
			// deal with the error code
			switch (GetLastError())
			{
				case ERROR_HANDLE_EOF:
				{
					// we have reached the end of the file
					// during the call to ReadFile
					break;
				}
				case ERROR_IO_PENDING:
				{
					// asynchronous i/o is still in progress
					switch(WaitForSingleObject(gOverlapped.hEvent, dwMilliseconds))
					{
						case WAIT_OBJECT_0:
							// check on the results of the asynchronous read
							// and update the nBytesRead...
							bResult = GetOverlappedResult(handle, &gOverlapped,
														  &nBytesRead, FALSE);
							if(!bResult)
							{
								printf("Error: %d", GetLastError());
							}
							else
							{
								if(pLength != NULL)
									*pLength = nBytesRead;
								dwResult = MPUSB_SUCCESS;
							}//end if else
							break;
						case WAIT_TIMEOUT:
							CancelIo(handle);
							break;
						default:
							CancelIo(handle);
							break;
					}//end switch
				}//end case
				default:
					CancelIo(handle);
					break;
			}//end switch
		}
		else
		{
			if(pLength != NULL)
				*pLength = nBytesRead;
			dwResult = MPUSB_SUCCESS;
		}//end if else

		ResetEvent(gOverlapped.hEvent);
		CloseHandle(gOverlapped.hEvent);
	}
	else
    {
        SetLastError(ERROR_NOACCESS);
    }

	return dwResult;
}

BOOL MPUSB::Close(IN HANDLE handle)
{
	BOOL rslt = TRUE;
    if(handle != INVALID_HANDLE_VALUE)
        rslt = CloseHandle(handle);
	return rslt;
}

// Private functions

///////////////////////////////////////////////////////////////////////////////
//	MPUSBIsVidPidEqual : Compares the pVID_PID string against the DeviceInstance
//  string retrieved from the registry using the DevicePath subkey.
//  This function should be called only from MPUSBGetDevicePath().
//
//  Note:
//  All Windows version has the DeviceClasses information stored in:
//  HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\DeviceClasses\\
//  {GUID_DEVINTERFACE_MCHPUSB}\\<DevicePath>
//  Win98SE,ME have different DevicePath string format from 2K,XP.
//  It does not contain vid&pid information in the DevicePath.
//  Thus necessitating the needs to check the DeviceInstance string in the
//  registry.
//
//	Note that "input" and "output" refer to the parameter designations in calls
//	to this function, which are the opposite of common sense from the
//	perspective of an application making the calls.
//
DWORD MPUSBIsVidPidEqual(PCHAR pDevicePath, PCHAR pVID_PID)
{
    DWORD dwResult = MPUSB_FAIL;
    char lszValue[255];
    char lpSubKey[512];

    HKEY hKey;
    LONG returnStatus;
    DWORD dwType=REG_SZ;
    DWORD dwSize=255;
    GUID guid = GUID_DEVINTERFACE_MCHPUSB;

    /* Modify DevicePath to use registry format */
    pDevicePath[0] = '#';
    pDevicePath[1] = '#';
    pDevicePath[3] = '#';

    /* Form SubKey */
    wsprintf(lpSubKey,
    "SYSTEM\\CURRENTCONTROLSET\\CONTROL\\DEVICECLASSES\\{%4.2x-%2.2x-%2.2x-%.2x%.2x-%.2x%.2x%.2x%.2x%.2x%.2x}\\%s",
    guid.Data1,guid.Data2,guid.Data3,guid.Data4[0],guid.Data4[1],guid.Data4[2],
    guid.Data4[3],guid.Data4[4],guid.Data4[5],guid.Data4[6],guid.Data4[7],pDevicePath);

    /* Open Key */
    returnStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                                lpSubKey,
                                0L,
                                KEY_ALL_ACCESS,
                                &hKey);
    if(returnStatus == ERROR_SUCCESS)
    {
        returnStatus = RegQueryValueEx(hKey,
                                       "DeviceInstance",
                                       NULL,
                                       &dwType,
                                       (LPBYTE)&lszValue,
                                       &dwSize);
        if(returnStatus == ERROR_SUCCESS)
        {
            /*
             * The string info stored in 'DeviceInstance' is the same
             * across all Windows platforms: 98SE, ME, 2K, and XP.
             * Upper-case in 98SE,ME.
             * Converts all to lower-case anyway.
             */
            _strlwr_s(lszValue);
            if(strstr(lszValue,pVID_PID) != NULL)
            {
                dwResult = MPUSB_SUCCESS;
            }
        }
    }
    RegCloseKey(hKey);

    /* Modify DevicePath to use the original format */
    pDevicePath[0] = '\\';
    pDevicePath[1] = '\\';
    pDevicePath[3] = '\\';

    return dwResult;
}//end

///////////////////////////////////////////////////////////////////////////////
//	GetDeviceLink : Returns the path to device hardware with a given
//  instance number.
//
//	Note that "input" and "output" refer to the parameter designations in calls
//	to this function, which are the opposite of common sense from the
//	perspective of an application making the calls.
//
DWORD MPUSB::GetDeviceLink(DWORD instance,    // Input
                         PCHAR pVID_PID,    // Input
                         PCHAR pPath,       // Output
                         DWORD dwLen,       // Input
                         PDWORD pLength)    // Output
{
    if(pLength != NULL)*pLength = 0;        // Initialization

    GUID guid = GUID_DEVINTERFACE_MCHPUSB;
    HDEVINFO info = SetupDiGetClassDevs((LPGUID)&guid,
                                        NULL,
                                        NULL,
                                        DIGCF_PRESENT|DIGCF_DEVICEINTERFACE);
    if(info==INVALID_HANDLE_VALUE)
	{
        SetupDiDestroyDeviceInfoList(info);
		return MPUSB_DEV_NO_INFO;
	}// end if

	// Get interface data for the requested instance
	SP_DEVICE_INTERFACE_DATA intf_data;
	intf_data.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

	if(!SetupDiEnumDeviceInterfaces(info,
                                    NULL,
                                    (LPGUID)&guid,
                                    instance,
                                    &intf_data))
	{
		SetupDiDestroyDeviceInfoList(info);
		return MPUSB_DEV_INVALID_INST;
	}// end if

	// Get size of symbolic link
	DWORD ReqLen;
	SetupDiGetDeviceInterfaceDetail(info, &intf_data, NULL, 0, &ReqLen, NULL);

	PSP_DEVICE_INTERFACE_DETAIL_DATA intf_detail = \
    (PSP_DEVICE_INTERFACE_DETAIL_DATA)(new char[ReqLen]);

	if( intf_detail == NULL)
	{
		SetupDiDestroyDeviceInfoList(info);
        delete intf_detail;
		return MPUSB_DEV_NO_INFO;
	}// end if

    // Get symbolic link name
	intf_detail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
    // sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA) should equals 5.
    // In C++ Builder, go to Project/Options/Advanced Compiler/Data Alignment
    // and select "byte" align.

	if(!SetupDiGetDeviceInterfaceDetail(info,
                                        &intf_data,
                                        intf_detail,
                                        ReqLen,
                                        NULL,
                                        NULL))
	{
		SetupDiDestroyDeviceInfoList(info);
		delete intf_detail;
		return MPUSB_DEV_NO_INFO;
	}// end if

    // Check for a valid VID&PID - if argument is not null)
    if(pVID_PID != NULL)
    {
        if(MPUSBIsVidPidEqual(intf_detail->DevicePath, pVID_PID) == NULL)
        {
            SetupDiDestroyDeviceInfoList(info);
		    delete intf_detail;
		    return MPUSB_DEV_VIDPID_NOT_FOUND;
        }// end if
    }// end if

	// Set the length of the path string
	if(pLength != NULL)
        *pLength = (DWORD)strlen(intf_detail->DevicePath);

    // Copy output string path to buffer pointed to by pPath
    if(pPath != NULL)
    {
        // Check that input buffer has enough room...
        // Use > not >= because strlen does not include null
        if(dwLen > strlen(intf_detail->DevicePath))
	        lstrcpy(pPath, intf_detail->DevicePath);
        else
        {
            SetupDiDestroyDeviceInfoList(info);
            delete intf_detail;
            return MPUSB_FAIL;
        }// end if
    }// end if

	// Clean up
	SetupDiDestroyDeviceInfoList(info);
	delete intf_detail;
	return MPUSB_SUCCESS;
}
