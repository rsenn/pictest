// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the MPUSBAPI_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// MPUSBAPI_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef MPUSBAPI_EXPORTS
#define MPUSBAPI_API __declspec(dllexport)
#else
#define MPUSBAPI_API __declspec(dllimport)
#endif

#define	MPUSB_FAIL                  0
#define MPUSB_SUCCESS               1

#define MP_WRITE                    0
#define MP_READ                     1

extern "C" MPUSBAPI_API
DWORD _MPUSBGetDLLVersion(void);

extern "C" MPUSBAPI_API
DWORD _MPUSBGetDeviceCount(PCHAR pVID_PID);

extern "C" MPUSBAPI_API
HANDLE _MPUSBOpen(DWORD instance,    // Input
                 PCHAR pVID_PID,    // Input
                 PCHAR pEP,         // Input
                 DWORD dwDir,       // Input
                 DWORD dwReserved); // Input <Future Use>

extern "C" MPUSBAPI_API
DWORD _MPUSBRead(HANDLE handle,              // Input
                PVOID pData,                // Output
                DWORD dwLen,                // Input
                PDWORD pLength,             // Output
                DWORD dwMilliseconds);      // Input

extern "C" MPUSBAPI_API
DWORD _MPUSBWrite(HANDLE handle,             // Input
                 PVOID pData,               // Input
                 DWORD dwLen,               // Input
                 PDWORD pLength,            // Output
                 DWORD dwMilliseconds);     // Input

extern "C" MPUSBAPI_API
DWORD _MPUSBReadInt(HANDLE handle,           // Input
                   PVOID pData,             // Output
                   DWORD dwLen,             // Input
                   PDWORD pLength,          // Output
                   DWORD dwMilliseconds);   // Input

extern "C" MPUSBAPI_API
BOOL _MPUSBClose(HANDLE handle);

