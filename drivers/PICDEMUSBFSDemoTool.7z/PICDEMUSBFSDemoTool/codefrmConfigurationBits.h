//---------------------------------------------------------------------------

#ifndef codefrmConfigurationBitsH
#define codefrmConfigurationBitsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
//---------------------------------------------------------------------------
struct tagConfigurationBitsData{
        int Index;
        unsigned long Address;
        AnsiString CategoryName;
        unsigned BitMask;
        unsigned Value;
        int OptionsMenuIndex;
        tagConfigurationBitsData(int aIndex,unsigned long aAddress,AnsiString aCategoryName,
                unsigned aBitMask,unsigned aValue,int aOptionsMenuIndex)
        {
                Index = aIndex;
                Address = aAddress;
                CategoryName= aCategoryName;
                BitMask=aBitMask;
                Value = aValue;
                OptionsMenuIndex = aOptionsMenuIndex;
        }


};

struct tagConfigOptions{
        int ConfigIndex;
        int Count;
        char *Text;
};

//---------------------------------------------------------------------------
class TfrmConfigurationBits : public TForm
{
__published:	// IDE-managed Components
        THeaderControl *HC;
        TComboBox *cmbOptions;
        TStringGrid *DG;
        void __fastcall HCSectionResize(
          THeaderControl *HeaderControl, THeaderSection *Section);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
        void __fastcall DGSelectCell(TObject *Sender, int ACol, int ARow,
          bool &CanSelect);
        void __fastcall cmbOptionsKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall DGKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
        TPanel *Panels[4];
        bool HandlingKeyPress;

public:		// User declarations
        __fastcall TfrmConfigurationBits(TComponent* Owner);
        void ResizeListBox(int ARow);
};

//---------------------------------------------------------------------------
extern PACKAGE TfrmConfigurationBits *frmConfigurationBits;
//---------------------------------------------------------------------------
#endif
